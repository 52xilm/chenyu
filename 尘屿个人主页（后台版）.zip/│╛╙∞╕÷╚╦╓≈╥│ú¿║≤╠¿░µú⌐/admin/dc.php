<?php
session_start();

// 清除会话中的登录状态
unset($_SESSION['logged_in']);

// 重定向到登录页面
header('Location: login.php');
exit;
?>