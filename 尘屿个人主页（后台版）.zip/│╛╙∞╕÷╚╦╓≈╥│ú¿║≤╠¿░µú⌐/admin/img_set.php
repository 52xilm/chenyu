<?php include '../config.php'; ?>
<!--作者：尘屿 -->
<?php
// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);


// 准备要插入的数据
$id = 1;
$tp1 = $_POST['web_site_tp1'];
$tp2 = $_POST['web_site_tp2'];;
$tp3 = $_POST['web_site_tp3'];;
$tp4 = $_POST['web_site_tp4'];;
$tp5 = $_POST['web_site_tp5'];;
$tp6 = $_POST['web_site_tp6'];;
$tp7 = $_POST['web_site_tp7'];;
$tp8 = $_POST['web_site_tp8'];;
$tp9 = $_POST['web_site_tp9'];;
$tp10 = $_POST['web_site_tp10'];;
$tp11 = $_POST['web_site_tp11'];;
$tp12 = $_POST['web_site_tp12'];;

// 尝试将数据插入到数据库中
$sql = "INSERT INTO imgset (id, tp1, tp2, tp3, tp4, tp5, tp6, tp7, tp8, tp9, tp10, tp11, tp12) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?,?)
        ON DUPLICATE KEY UPDATE tp1 = VALUES(tp1), tp2 = VALUES(tp2), tp3 = VALUES(tp3), tp4 = VALUES(tp4), tp5 = VALUES(tp5), tp6 = VALUES(tp6), tp7 = VALUES(tp7), tp8 = VALUES(tp8), tp9 = VALUES(tp9), tp10 = VALUES(tp10), tp11 = VALUES(tp11), tp12 = VALUES(tp12)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssssssss", $id, $tp1, $tp2, $tp3, $tp4, $tp5, $tp6, $tp7, $tp8, $tp9, $tp10, $tp11, $tp12);

if ($stmt->execute() === TRUE) {
   echo "";
} else {
    // 捕获异常
  echo "";
}

$stmt->close();
$conn->close();



?>
<?php
$configs = include('./php/sql.php');
?>
<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] != true) {
    // 用户未登录，重定向到登录页面
    header('Location: login.php');
    exit;
}

// 在这里显示已登录用户的内容
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>后台管理</title>
<link rel="icon" href="favicon.ico" type="image/ico">
<meta name="author" content="yinqi">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/materialdesignicons.min.css" rel="stylesheet">
<link href="css/style.min.css" rel="stylesheet">
</head>
  
<body>
<div class="lyear-layout-web">
  <div class="lyear-layout-container">
    <!--左侧导航-->
    <aside class="lyear-layout-sidebar">
       
      <!-- logo -->
      <div id="logo" class="sidebar-header">
        <a href="index.php"><img src="images/logo-sidebar.png"  height="75px"/></a>
      </div>
      <div class="lyear-layout-sidebar-scroll">
        
        <nav class="sidebar-main">
          <ul class="nav nav-drawer">
            <li class="nav-item "> <a href="index.php"><i class="mdi mdi-home"></i> 后台首页</a></li>
            <li class="nav-item "> <a href="web_set.php"><i class="mdi mdi-web"></i> 网站配置</a></li>
            <li class="nav-item active"> <a href="img_set.php"><i class="mdi mdi-image"></i> 图片配置</a></li>
            <li class="nav-item "> <a href="link_set.php"><i class="mdi mdi-link-variant"></i> 链接配置</a></li>
            <li class="nav-item "> <a href="top_set.php"><i class="mdi mdi-monitor"></i> 头部配置</a></li>
            <li class="nav-item "> <a href="other_set.php"><i class="mdi mdi-alert-circle-outline"></i> 其他配置</a></li>
              </ul>
        </nav>
        
        <div class="sidebar-footer">
          <p class="copyright">Copyright &copy; 2024. <a target="_blank" href=""><?php echo $configs['web_site_title']; ?></a> All rights reserved.</p>
        </div>
      </div>
      
    </aside>
    <!--End 左侧导航-->
    
    <!--头部信息-->
    <header class="lyear-layout-header">
      
      <nav class="navbar navbar-default">
        <div class="topbar">
          
          <div class="topbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
            <span class="navbar-page-title"> 图片 </span>
          </div>
          
          <ul class="topbar-right">
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown">
                <img src="https://imgapi.cn/qq.php?qq=<?php echo $configs['web_site_qq']; ?>" style="width:50px;height:50px;border-radius:100%;">
                <span><?php echo $configs['web_site_author']; ?> <span class="caret"></span></span>
              </a>
              <ul class="dropdown-menu dropdown-menu-right">
                <li> <a href="pwd.php"><i class="mdi mdi-lock-outline"></i> 修改密码</a> </li>
                <li> <a href="javascript:void(0)"><i class="mdi mdi-delete"></i> 清空缓存</a></li>
                <li class="divider"></li>
                <li> <a href="dc.php"><i class="mdi mdi-logout-variant"></i> 退出登录</a> </li>
              </ul>
            </li>
            <!--切换主题配色-->
		    <li class="dropdown dropdown-skin">
			  <span data-toggle="dropdown" class="icon-palette"><i class="mdi mdi-palette"></i></span>
			  <ul class="dropdown-menu dropdown-menu-right" data-stopPropagation="true">
                <li class="drop-title"><p>主题</p></li>
                <li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="site_theme" value="default" id="site_theme_1" checked>
                    <label for="site_theme_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="dark" id="site_theme_2">
                    <label for="site_theme_2"></label>
                  </span>
                  <span>
                    <input type="radio" name="site_theme" value="translucent" id="site_theme_3">
                    <label for="site_theme_3"></label>
                  </span>
                </li>
			    <li class="drop-title"><p>LOGO</p></li>
				<li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="logo_bg" value="default" id="logo_bg_1" checked>
                    <label for="logo_bg_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_2" id="logo_bg_2">
                    <label for="logo_bg_2"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_3" id="logo_bg_3">
                    <label for="logo_bg_3"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_4" id="logo_bg_4">
                    <label for="logo_bg_4"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_5" id="logo_bg_5">
                    <label for="logo_bg_5"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_6" id="logo_bg_6">
                    <label for="logo_bg_6"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_7" id="logo_bg_7">
                    <label for="logo_bg_7"></label>
                  </span>
                  <span>
                    <input type="radio" name="logo_bg" value="color_8" id="logo_bg_8">
                    <label for="logo_bg_8"></label>
                  </span>
				</li>
				<li class="drop-title"><p>头部</p></li>
				<li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="header_bg" value="default" id="header_bg_1" checked>
                    <label for="header_bg_1"></label>                      
                  </span>                                                    
                  <span>                                                     
                    <input type="radio" name="header_bg" value="color_2" id="header_bg_2">
                    <label for="header_bg_2"></label>                      
                  </span>                                                    
                  <span>                                                     
                    <input type="radio" name="header_bg" value="color_3" id="header_bg_3">
                    <label for="header_bg_3"></label>
                  </span>
                  <span>
                    <input type="radio" name="header_bg" value="color_4" id="header_bg_4">
                    <label for="header_bg_4"></label>                      
                  </span>                                                    
                  <span>                                                     
                    <input type="radio" name="header_bg" value="color_5" id="header_bg_5">
                    <label for="header_bg_5"></label>                      
                  </span>                                                    
                  <span>                                                     
                    <input type="radio" name="header_bg" value="color_6" id="header_bg_6">
                    <label for="header_bg_6"></label>                      
                  </span>                                                    
                  <span>                                                     
                    <input type="radio" name="header_bg" value="color_7" id="header_bg_7">
                    <label for="header_bg_7"></label>
                  </span>
                  <span>
                    <input type="radio" name="header_bg" value="color_8" id="header_bg_8">
                    <label for="header_bg_8"></label>
                  </span>
				</li>
				<li class="drop-title"><p>侧边栏</p></li>
				<li class="drop-skin-li clearfix">
                  <span class="inverse">
                    <input type="radio" name="sidebar_bg" value="default" id="sidebar_bg_1" checked>
                    <label for="sidebar_bg_1"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_2" id="sidebar_bg_2">
                    <label for="sidebar_bg_2"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_3" id="sidebar_bg_3">
                    <label for="sidebar_bg_3"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_4" id="sidebar_bg_4">
                    <label for="sidebar_bg_4"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_5" id="sidebar_bg_5">
                    <label for="sidebar_bg_5"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_6" id="sidebar_bg_6">
                    <label for="sidebar_bg_6"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_7" id="sidebar_bg_7">
                    <label for="sidebar_bg_7"></label>
                  </span>
                  <span>
                    <input type="radio" name="sidebar_bg" value="color_8" id="sidebar_bg_8">
                    <label for="sidebar_bg_8"></label>
                  </span>
				</li>
			  </ul>
			</li>
            <!--切换主题配色-->
          </ul>
          
        </div>
      </nav>
      
    </header>
    <!--End 头部信息-->
    
    <!--页面主要内容-->
    <main class="lyear-layout-content">
      
      <div class="container-fluid">
        
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
              <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">图片</a> </li>
              </ul>
              <div class="tab-content">
                <div class="tab-pane active">
                  
                  <form action="#!" method="post" name="edit-form" class="edit-form">
                    <div class="form-group">
                      <label for="web_site_tp1">音乐封面</label>
                      <input class="form-control" type="text" id="web_site_tp1" name="web_site_tp1" value="<?php echo $configs['web_site_tp1']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp2">LOGO1</label>
                      <input class="form-control" type="text" id="web_site_tp2" name="web_site_tp2" value="<?php echo $configs['web_site_tp2']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp3">LOGO2</label>
                      <input class="form-control" type="text" id="web_site_tp3" name="web_site_tp3" value="<?php echo $configs['web_site_tp3']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp4">左导航icon1</label>
                      参考<a href="https://fontawesome.com/search?m=free&o=r">Font Awesome</a>
                      <input class="form-control" type="text"id="web_site_tp4"  name="web_site_tp4" value="<?php echo $configs['web_site_tp4']; ?>" placeholder="请输入图片链接/路径" >
                      <small class="help-block">填写格式：<code>fa-solid fa-house</code></small>
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp5">左导航icon2</label>
                      <input class="form-control" type="text" id="web_site_tp5" name="web_site_tp5" value="<?php echo $configs['web_site_tp5']; ?>" placeholder="请输入图片链接/路径" >
                      <small class="help-block">填写格式：<code>fa-solid fa-house</code></small>
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp6">左导航icon3</label>
                      <input class="form-control" type="text" id="web_site_tp6" name="web_site_tp6" value="<?php echo $configs['web_site_tp6']; ?>" placeholder="请输入图片链接/路径" >
                      <small class="help-block">填写格式：<code>fa-solid fa-house</code></small>
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp7">左导航icon4</label>
                      <input class="form-control" type="text" id="web_site_tp7" name="web_site_tp7" value="<?php echo $configs['web_site_tp7']; ?>" placeholder="请输入图片链接/路径" >
                      <small class="help-block">填写格式：<code>fa-solid fa-house</code></small>
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp8">右导航icon1</label>
                      <input class="form-control" type="text" id="web_site_tp8" name="web_site_tp8" value="<?php echo $configs['web_site_tp8']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp9">右导航icon2</label>
                      <input class="form-control" type="text" id="web_site_tp9" name="web_site_tp9" value="<?php echo $configs['web_site_tp9']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp10">右导航icon3</label>
                      <input class="form-control" type="text" id="web_site_tp10" name="web_site_tp10" value="<?php echo $configs['web_site_tp10']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp11">赞赏码1</label>
                      <input class="form-control" type="text" id="web_site_tp11" name="web_site_tp11" value="<?php echo $configs['web_site_tp11']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                      <label for="web_site_tp12">赞赏码2</label>
                      <input class="form-control" type="text" id="web_site_tp12" name="web_site_tp12" value="<?php echo $configs['web_site_tp12']; ?>" placeholder="请输入图片链接/路径" >
                    </div>
                    <div class="form-group">
                        <form><button type="submit" class="btn btn-primary m-r-5">确 定</button></form>
                      <button type="button" class="btn btn-default" onclick="javascript:history.back(-1);return false;">返 回</button>
                    </div>
                  </form>
                  
                </div>
              </div>

            </div>
          </div>
          
        </div>
        
      </div>
      
    </main>
    <!--End 页面主要内容-->
  </div>
</div>

<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="js/main.min.js"></script>
</body>
</html>