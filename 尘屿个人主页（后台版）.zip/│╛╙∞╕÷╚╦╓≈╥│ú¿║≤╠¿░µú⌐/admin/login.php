<!DOCTYPE html>
<!--作者：尘屿 -->
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>登录页面</title>
<link rel="icon" href="favicon.ico" type="image/ico">
<meta name="author" content="yinqi">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/materialdesignicons.min.css" rel="stylesheet">
<link href="css/style.min.css" rel="stylesheet">
<style>
.lyear-wrapper {
    position: relative;
}
.lyear-login {
    background: linear-gradient(90deg, #f7cddb,#add2f1);
    display: flex !important;
    min-height: 100vh;
    align-items: center !important;
    justify-content: center !important;
}
.lyear-login:after{
    content: '';
    min-height: inherit;
    font-size: 0;
}
.login-center {
    background-color: rgba(0,0,0,0.4);
    min-width: 29.25rem;
    padding: 2.14286em 3.57143em;
    border-radius: 10px;
    margin: 2.85714em;
}
.login-header {
    margin-bottom: 1.5rem !important;
}
.login-center .has-feedback.feedback-left .form-control {
    padding-left: 38px;
    padding-right: 12px;
    background-color: rgba(0,0,0,0);
    border-color: #d2d2d2;
}
.login-center .has-feedback.feedback-left .form-control-feedback {
    left: 0;
    right: auto;
    width: 38px;
    height: 38px;
    line-height: 38px;
    z-index: 4;
    color: #dcdcdc;
}
.login-center .has-feedback.feedback-left.row .form-control-feedback {
    left: 15px;
}
.login-center .form-control::-webkit-input-placeholder{ 
    color: rgba(255, 255, 255, .8);
} 
.login-center .form-control:-moz-placeholder{ 
    color: rgba(255, 255, 255, .8);
} 
.login-center .form-control::-moz-placeholder{ 
    color: rgba(255, 255, 255, .8);
} 
.login-center .form-control:-ms-input-placeholder{ 
    color: rgba(255, 255, 255, .8);
}
.login-center .custom-control-label::before {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(0, 0, 0, 0.1);
}
.login-center .lyear-checkbox span::before {
    border-color: rgba(255,255,255,.075)
}
</style>
</head>
  <?php
session_start();

// 获取表单提交的用户名和密码
$username = $_POST['username'];
$password = $_POST['password'];

// 在这里验证用户名和密码
if ($username == 'admin' && $password == '123456') {
    // 登录成功
    $_SESSION['logged_in'] = true; // 保存登录状态
    header('Location: index.php'); // 重定向到主页
    exit;
} else {
    // 登录失败
   
}
?>
<body>
<div class="row lyear-wrapper" style="background-color:#f2f1f6; background-size: cover;">
  <div class="lyear-login">
    <div class="login-center">
      <div class="login-header text-center">
        <a href=""> <img style="border-radius:100%; width:100px; height:100px;" src="images/logo-sidebar.png"> </a>
      </div>
      <form action="#!" method="post">
        <div class="form-group has-feedback feedback-left">
          <input type="text" placeholder="请输入您的用户名" class="form-control" name="username" id="username" />
          <span class="mdi mdi-account form-control-feedback" aria-hidden="true"></span>
        </div>
        <div class="form-group has-feedback feedback-left">
          <input type="password" placeholder="请输入密码" class="form-control" id="password" name="password" />
          <span class="mdi mdi-lock form-control-feedback" aria-hidden="true"></span>
        </div>
     <div class="form-group has-feedback feedback-left row">
        <!--  <div class="col-xs-7">
            <input type="text" name="captcha" class="form-control" placeholder="验证码">
            <span class="mdi mdi-check-all form-control-feedback" aria-hidden="true"></span>
          </div>
          <div class="col-xs-5">
            <img src="images/captcha.png" class="pull-right" id="captcha" style="cursor: pointer;" onclick="this.src=this.src+'?d='+Math.random();" title="点击刷新" alt="captcha">
          </div>-->
        </div>
        <div class="form-group">
          <label class="lyear-checkbox checkbox-primary m-t-10 text-white">
            <input type="checkbox"><span>5天内自动登录</span>
          </label>
        </div>
        <div class="form-group">
            <form>
          <button class="btn btn-block btn-primary" type="submit" >立即登录</button></form>
        </div>
      </form>
      <footer class="col-sm-12 text-center text-white">
      </footer>
    </div>
  </div>
</div>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript">;</script>
</body>
</html>