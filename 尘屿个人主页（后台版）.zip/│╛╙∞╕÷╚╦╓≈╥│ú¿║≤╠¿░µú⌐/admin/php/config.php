<?php
// 连接到数据库
$servername = "localhost";
$username = "sbis_cn";
$password = "n5b3a44xaG86nMNL";
$dbname = "sbis_cn";
?>