<?php include"config.php" ?>
<?php

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 定义查询语句
$sql = "SELECT * FROM webset WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        $title = $row["title"];
        $icp = $row["icp"];
        $qq = $row["qq"];
        $keywords = $row["keywords"];
        $description = $row["description"];
      //echo $qqh;
     //   echo "<br>";
     //   echo $icp;
    }
} else {
    echo "0 结果";
}
$conn->close();

?>
<?php
return array(
    'web_site_title' => $title,
    'web_site_icp' => $icp,
    'web_site_qq' => $qq,
    'web_site_keywords' => $keywords,
    'web_site_description' => $description,
    // 其他配置项...
);