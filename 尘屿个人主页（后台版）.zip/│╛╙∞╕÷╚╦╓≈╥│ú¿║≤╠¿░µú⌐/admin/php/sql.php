<?php include"config.php" ?>
<?php

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 检查连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
}

// 定义查询语句
$sql = "SELECT * FROM imgset WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        $tp1 = $row["tp1"];
        $tp2 = $row["tp2"];
        $tp3 = $row["tp3"];
        $tp4 = $row["tp4"];
        $tp5 = $row["tp5"];
        $tp6 = $row["tp6"];
        $tp7 = $row["tp7"];
        $tp8 = $row["tp8"];
        $tp9 = $row["tp9"];
        $tp10 = $row["tp10"];
        $tp11 = $row["tp11"];
        $tp12 = $row["tp12"];
      //echo $qqh;
     //   echo "<br>";
     //   echo $icp;
    }
} else {
    echo "0 结果";
}
$sql = "SELECT * FROM webset WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        $title = $row["title"];
        $icp = $row["icp"];
        $qq = $row["qq"];
        $keywords = $row["keywords"];
        $description = $row["description"];
      //echo $qqh;
     //   echo "<br>";
     //   echo $icp;
    }
} else {
    echo "0 结果";
}
$sql = "SELECT * FROM linkset WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        $lj1 = $row["lj1"];
        $lj2 = $row["lj2"];
        $lj3 = $row["lj3"];
        $lj4 = $row["lj4"];
        $lj5 = $row["lj5"];
        $mc5 = $row["mc5"];
        $lj6 = $row["lj6"];
        $lj7 = $row["lj7"];
        $lj8 = $row["lj8"];
      //echo $qqh;
     //   echo "<br>";
     //   echo $icp;
    }
} else {
    echo "0 结果";
}
$sql = "SELECT * FROM topset WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        $pagename = $row['pagename'];
        $sign = $row['sign'];
        $statecolor = $row['statecolor'];
        $state = $row['state'];
        $emoji = $row['emoji'];
        $phone = $row['phone'];
        
 
    }
} else {
    echo "0 结果";
}
$sql = "SELECT * FROM otherset WHERE 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // 输出每行数据
    while($row = $result->fetch_assoc()) {
        $greet = $row["greet"];
        $sitetext = $row["sitetext"];
        $edition = $row["edition"];
        $forward = $row["forward"];
        $author = $row["author"];
        $skill1 = $row["skill1"];
        $skill2 = $row["skill2"];
        $skill3 = $row["skill3"];
        $skill4 = $row["skill4"];
        $slide1 = $row["slide1"];
        $slidelink1 = $row["slidelink1"];
        $slide2 = $row["slide2"];
        $slidelink2 = $row["slidelink2"];
        $slide3 = $row["slide3"];
        $slidelink3 = $row["slidelink3"];
        $slide4 = $row["slide4"];
        $slidelink4 = $row["slidelink4"];
        $slide5 = $row["slide5"];
        $slidelink5 = $row["slidelink5"];
        $slide6 = $row["slide6"];
        $slidelink6 = $row["slidelink6"];
        $contact1icon = $row["contact1icon"];
        $contact1link = $row["contact1link"];
        $contact2icon = $row["contact2icon"];
        $contact2link = $row["contact2link"];
        $contact3icon = $row["contact3icon"];
        $contact3link = $row["contact3link"];
        $contact4icon = $row["contact4icon"];
        $contact4link = $row["contact4link"];
        $fate = $row["fate"];
        $footer = $row["footer"];
        
 
    }
} else {
    echo "0 结果";
}
//$conn->close()

?>
<?php
return array(
    'web_site_tp1' => $tp1,
    'web_site_tp2' => $tp2,
    'web_site_tp3' => $tp3,
    'web_site_tp4' => $tp4,
    'web_site_tp5' => $tp5,
    'web_site_tp6' => $tp6,
    'web_site_tp7' => $tp7,
    'web_site_tp8' => $tp8,
    'web_site_tp9' => $tp9,
    'web_site_tp10' => $tp10,
    'web_site_tp11' => $tp11,
    'web_site_tp12' => $tp12,
    
    'web_site_title'=> $title,
    'web_site_icp' => $icp,
    'web_site_qq' => $qq,
    'web_site_keywords' => $keywords,
    'web_site_description' => $description,
    
    'web_site_lj1' => $lj1,
    'web_site_lj2' => $lj2,
    'web_site_lj3' => $lj3,
    'web_site_lj4' => $lj4,
    'web_site_lj5' => $lj5,
    'web_site_mc5' => $mc5,
    'web_site_lj6' => $lj6,
    'web_site_lj7' => $lj7,
    'web_site_lj8' => $lj8,
    
    'web_site_pagename' => $pagename,
    'web_site_sign'=> $sign,
    'web_site_statecolor' => $statecolor,
    'web_site_state' => $state,
    'web_site_emoji' => $emoji,
    'web_site_phone' => $phone,
    
    'web_site_greet' => $greet,
    'web_site_sitetext' => $sitetext,
    'web_site_edition' => $edition,
    'web_site_forward' => $forward,
    'web_site_author' => $author,
    'web_site_skill1' => $skill1,
    'web_site_skill2' => $skill2,
    'web_site_skill3' => $skill3,
    'web_site_skill4' => $skill4,
    'web_site_slide1' => $slide1,
    'web_site_slidelink1' => $slidelink1,
    'web_site_slide2' => $slide2,
    'web_site_slidelink2' => $slidelink2,
    'web_site_slide3' => $slide3,
    'web_site_slidelink3' => $slidelink3,
    'web_site_slide4' => $slide4,
    'web_site_slidelink4' => $slidelink4,
    'web_site_slide5' => $slide5,
    'web_site_slidelink5' => $slidelink5,
    'web_site_slide6' => $slide6,
    'web_site_slidelink6' => $slidelink6,
    'web_site_contact1icon' => $contact1icon,
    'web_site_contact1link' => $contact1link,
    'web_site_contact2icon' => $contact2icon,
    'web_site_contact2link' => $contact2link,
    'web_site_contact3icon' => $contact3icon,
    'web_site_contact3link' => $contact3link,
    'web_site_contact4icon' => $contact4icon,
    'web_site_contact4link' => $contact4link,
    'web_site_fate' => $fate,
    'web_site_footer' => $footer,
    
    '$username' => $username,
    '$password' => $password,
    // 其他配置项...
);

