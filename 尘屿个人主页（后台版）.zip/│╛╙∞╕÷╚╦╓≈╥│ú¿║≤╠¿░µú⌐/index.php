<?php $configs = include('./admin/php/sql.php');
?>
<!doctype html>
<!--作者：尘屿 -->
<html lang="en">
<head>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo $configs['web_site_title']; ?></title>
    <meta name="description" content="<?php echo $configs['web_site_description']; ?>">
    <meta name="keywords" content="<?php echo $configs['web_site_keywords']; ?>">
    <link rel="icon" type="/ico" href="/favicon.ico">
    <link rel="stylesheet" href="static/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.staticfile.net/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="static/css/animate.min.css">
    <script src="static/js/jquery-3.5.1.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/player.js"></script>
    <script src="static/js/dark.js"></script>
    <script src="static/js/jquery.min.js"></script>
    <link rel="stylesheet" href="static/css/style.css">
    <link href="https://fonts.googlefonts.cn/css?family=Capriola" rel="stylesheet">


    <script>
      $(document).ready(function(){
        $('.toast').toast('show');
      });
    </script>
    <script type="module"> import emoji-datasource from 'https://cdn.jsdelivr.net/npm/emoji-datasource@15.1.2/+esm '</script>
    
  
    

<style>

body.dark-mode{
    --dark-mode-text-color:rgb(245, 245, 245);
    --dark-mode-body:#3d3d3d;
    --dark-mode-toggle-translate:15px;
    --dark-mode-body1:url(static/img/moon-solid.svg);
}
.mode-switch__circle{
    height: 15px;
    width: 15px;
    border-radius: 100px;
    background:var(--dark-mode-body1,url(static/img/sun-regular.svg));
    transform: translateX(var(--dark-mode-toggle-translate,0));
    transition: transfore 0.3s ease;
    pointer-events: none;
    transition: 0.4s;
}    

</style>
</head>

<body>
  <div class="toast animate__animated animate__pulse" role="alert" aria-live="assertive" aria-atomic="true" data-delay="1500">
    <div class="toast-body">
      <span><?php echo $configs['web_site_greet']; ?></span>
    </div>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="left">
        
        <div class="flex-container">
          <div><img src="https://imgapi.cn/qq.php?qq=<?php echo $configs['web_site_qq']; ?>" class="touxi"></div>
          <div class="gexing">
            <div class="flex-container">
              <div class="toem"><?php echo $configs['web_site_pagename']; ?></div>
            </div>
            <div class="flex-container">
              <div class="sign"><?php echo $configs['web_site_sign']; ?></div>
            </div>
            <div class="flex-container">
              <div class="state"><i class="fa-solid fa-circle fa-2xs" style="color: <?php echo $configs['web_site_statecolor']; ?>;"></i><span style="font-size: 13px ">&nbsp;<?php echo $configs['web_site_phone']; ?>&nbsp;<?php echo $configs['web_site_state']; ?>&nbsp;</span><?php echo $configs['web_site_emoji']; ?></div>
            </div>
          </div>
          <div><button type="button" class="btn btn-link" data-toggle="modal" data-target="#exampleModal" style=" margin: 35px 0 0 25px; color: var(--dark-mode-text-color,#141414);"><i class="fa-solid fa-qrcode fa-lg"></i></button></div>  
        </div>
            <hr style="margin: 0; margin-top: 10px; margin-bottom: 10px;">
            <div class="flex-container justify-content-center" style="width:auto;">
                
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #f70808;"></i>&nbsp;<?php echo $configs['web_site_skill1']; ?>&nbsp;</div>
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #63e6be;"></i>&nbsp;<?php echo $configs['web_site_skill2']; ?>&nbsp;</div>
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #74C0FC;"></i>&nbsp;<?php echo $configs['web_site_skill3']; ?>&nbsp;</div>
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #ea875e;"></i>&nbsp;<?php echo $configs['web_site_skill4']; ?>&nbsp;</div>
            </div>

        <div class="row justify-content-center">
          <div class="left-4-1 animate__animated animate__pulse">
            <span>
              <img src="<?php echo $configs['web_site_tp1']; ?>" style="width: 33px;height: 33px;border-radius: 6px;margin: 5px 0 0 5px;">
              <div class="sh-main-top-mu" lang="0" onclick="syaudbf()"><i class="fa-regular fa-circle-play fa-lg" id="sh-main-top-mu" lang="0" data-bfzt="bb"></i></div>
            </span>
            <div id="sh-main-top-g-m" class="sh-main-top-g-containe" lang="在你的身边">
              <div id="sh-main-top-mucisjd" lang="0" style="display:none;">
                  <div class="shaft-load2">
                  <div class="shaft1"></div>
                  <div class="shaft2"></div>
                  <div class="shaft3"></div>
                  <div class="shaft4"></div>
                  <div class="shaft5"></div>
                  <div class="shaft6"></div>
                  <div class="shaft7"></div>
                  <div class="shaft8"></div>
                  <div class="shaft9"></div>
                  <div class="shaft10"></div>
                  <div class="shaft11"></div>
                  <div class="shaft12"></div>
                  <div class="shaft13"></div>
                  <div class="shaft14"></div>
                  <div class="shaft15"></div>
                  <div class="shaft16"></div>
                  <div class="shaft17"></div>
                  <div class="shaft18"></div>
                  <div class="shaft19"></div>
                  <div class="shaft20"></div>
                  </div>
              </div>
            </div>
            <audio id="sh-main-top-musicplay-b" src="<?php echo $configs['web_site_lj6']; ?>" type="audio/mp3" controls="controls" style="display: none;"></audio>
            <audio id="musicplay" src="" type="audio/mp3" controls="controls" style="display: none;" lang="0" class="">您的浏览器不支持音频元素。</audio>   
          </div>

          <div class="left-4-2 animate__animated animate__pulse"><img src="<?php echo $configs['web_site_tp2']; ?>"></div>
          <button class="btn btn-link animate__animated animate__pulse" type="button" data-toggle="collapse" data-target="#coll" aria-expanded="false" aria-controls="coll"style="margin-left: 7px;margin-top: 20px;width: 50px;height: 50px;border-radius: 10px;padding-bottom: 10px;background: var(--dark-mode-body,#fefefe);margin-bottom: 10px;float: left;">
            <i class="fa-solid fa-bars fa-lg"></i></button>
          <div class="left-4-4 animate__animated animate__pulse"><img src="<?php echo $configs['web_site_tp3']; ?>"></div>
          <div class="collapse" id="coll" >
            <div class="card card-body" style="border-radius: 10px; display: inline-block; height: 40px; padding: 0; background: var(--dark-mode-body,#fefefe);">
              <button type="button" class="btn btn-link" data-toggle="modal" data-target="#site"><img src="static/img/globe.svg" style="width: 25px;height: 25px;"></button>
              <button onclick="switchSakura()" class="btn btn-link"><i class="fa-regular fa-circle-xmark fa-lg "style="color: pink;"></i></button>
              <button type="button" class="btn btn-link" data-toggle="modal" data-target="#about"><img src="static/img/information.svg" style="width: 25;height: 25px;"></button>
            </div>
          </div>
          
        </div>

        <div class="flex-container justify-content-center">
          <div class="applesb animate__animated animate__pulse">
            <div class="flex-container justify-content-center">
              <a href="<?php echo $configs['web_site_lj1']; ?>" class="applesb-1"><i class="<?php echo $configs['web_site_tp4']; ?>"></i></a>
              <a href="<?php echo $configs['web_site_lj2']; ?>" class="applesb-1"><i class="<?php echo $configs['web_site_tp5']; ?>"></i></a>
            </div>
            <div class="flex-container justify-content-center">
              <a href="<?php echo $configs['web_site_lj3']; ?>" class="applesb-1"><i class="<?php echo $configs['web_site_tp6']; ?>"></i></a>
              <a href="<?php echo $configs['web_site_lj4']; ?>" class="applesb-1"><i class="<?php echo $configs['web_site_tp7']; ?>"></i></a>
            </div>
          </div>
          <div class="applesb">
            <div class="flex-container justify-content-center animate__animated animate__pulse">
              <a href="<?php echo $configs['web_site_lj7']; ?>" class="applesb-2"><img src="<?php echo $configs['web_site_tp8']; ?>"></a>
              <a href="<?php echo $configs['web_site_lj8']; ?>" class="applesb-2"><img src="<?php echo $configs['web_site_tp9']; ?>"></a>
            </div>
            <div class="flex-container justify-content-center">
              <a href="<?php echo $configs['web_site_lj5']; ?>" class="applesb-3"><img src="<?php echo $configs['web_site_tp10']; ?>">&nbsp;<?php echo $configs['web_site_mc5']; ?></a>
            </div>
          </div>
        </div>

        <div class="slide-bar">
          <div class="slide-centent"><a href="<?php echo $configs['web_site_slidelink1']; ?>"><?php echo $configs['web_site_slide1']; ?></a></div>
          <div class="slide-centent"><a href="<?php echo $configs['web_site_slidelink2']; ?>"><?php echo $configs['web_site_slide2']; ?></a></div>
          <div class="slide-centent"><a href="<?php echo $configs['web_site_slidelink3']; ?>"><?php echo $configs['web_site_slide3']; ?></a></div>
          <div class="slide-centent"><a href="<?php echo $configs['web_site_slidelink4']; ?>"><?php echo $configs['web_site_slide4']; ?></a></div>
          <div class="slide-centent"><a href="<?php echo $configs['web_site_slidelink5']; ?>"><?php echo $configs['web_site_slide5']; ?></a></div>
          <div class="slide-centent"><a href="<?php echo $configs['web_site_slidelink6']; ?>"><?php echo $configs['web_site_slide6']; ?></a></div>
        </div>
 
        <div class="flex-container justify-content-center">
          <div class="left-3 animate__animated animate__pulse">
            <a href="<?php echo $configs['web_site_contact1link']; ?>"><i class="<?php echo $configs['web_site_contact1icon']; ?>" style="color:#a0d5ff;"></i></a>
            <a href="<?php echo $configs['web_site_contact2link']; ?>"><i class="<?php echo $configs['web_site_contact2icon']; ?>" style="color:#ffc19c;"></i></a>
            <a href="<?php echo $configs['web_site_contact3link']; ?>"><i class="<?php echo $configs['web_site_contact3icon']; ?>" style="color: black;"></i></a>
            <a href="<?php echo $configs['web_site_contact4link']; ?>"><i class="<?php echo $configs['web_site_contact4icon']; ?>" style="color:pink;"></i></a>
          </div>
          <div class="left-3-2 animate__animated animate__pulse">
            <div class="mode-switch">
              <div class="mode-switch__toggle">
              <div class="mode-switch__circle">
              </div></div>
            </div>
          </div>
          <div class="left-3-3 animate__animated animate__pulse">
            <a href="/admin"><i class="fa-regular fa-circle-user fa-lg"></i></a>
          </div>
        </div>

      </div>
     </div>

        

      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered row justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border-radius: 10px; background: var(--dark-mode-body,#f2f1f6); width: 300px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><i class="fa-solid fa-quote-left" style="color: #fb7474;"></i>&nbsp;赞赏框&nbsp;|&nbsp;为爱打赏&nbsp;<i class="fa-solid fa-quote-right" style="color: #fb7474;"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <img src="<?php echo $configs['web_site_tp11']; ?>" class="zanshang">
              <img src="<?php echo $configs['web_site_tp12']; ?>" class="zfb">
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="about" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border-radius: 10px; background: var(--dark-mode-body,#f2f1f6); width: 280px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><i class="fa-solid fa-quote-left" style="color: #74C0FC;"></i>&nbsp;关于&nbsp;<i class="fa-solid fa-quote-right" style="color: #74C0FC"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <span><i class="fa-regular fa-note-sticky" style="color:#74C0FC;">&nbsp;</i>&nbsp;<?php echo $configs['web_site_edition']; ?></span>
              <hr>
              <span><i class="fa-regular fa-comment" style="color: #63e6be;">&nbsp;</i>&nbsp;<?php echo $configs['web_site_forward']; ?></span>
              <hr>
              <span><i class="fa-regular fa-user">&nbsp;</i>&nbsp;<?php echo $configs['web_site_author']; ?></span>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="site" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border-radius: 10px; background: var(--dark-mode-body,#f2f1f6); width: 250px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><i class="fa-solid fa-quote-left" style="color: #74C0FC;"></i>&nbsp;旗下站点&nbsp;<i class="fa-solid fa-quote-right" style="color: #74C0FC"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="sitetext"><?php echo $configs['web_site_sitetext']; ?></div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <footer class="fixed-booten">
      <div id="runtime_span" class="runtime"></div>
      <script>function show_runtime(){window.setTimeout("show_runtime()",1000);X=new 
        Date("<?php echo $configs['web_site_fate']; ?> 00:00:00");
        Y=new Date();T=(Y.getTime()-X.getTime());M=24*60*60*1000;
        a=T/M;A=Math.floor(a);b=(a-A)*24;B=Math.floor(b);c=(b-B)*60;C=Math.floor((b-B)*60);D=Math.floor((c-C)*60);
        runtime_span.innerHTML="已运行:&nbsp;"+A+"&nbsp;天&nbsp;"+B+"&nbsp;小时&nbsp;"+C+"&nbsp;分&nbsp;"+D+"&nbsp;秒"}show_runtime();
      </script>
      <div class="by"><?php echo $configs['web_site_footer']; ?></div>
      <div class="by"><i class="fa-regular fa-copyright fa-sm"></i>&nbsp;2024&nbsp;尘屿小站&nbsp;|&nbsp;Designed&nbsp;by<a href="" style="text-decoration: none;">&nbsp;ChenYu</a></div>
      <div class="body-bottom">
        <a href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank"><img src="static/img/icp.svg"><?php echo $configs['web_site_icp']; ?></a>
      </div>
    </footer>
</body>

</html>