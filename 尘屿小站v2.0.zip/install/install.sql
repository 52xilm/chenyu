-- MySQL dump 10.13  Distrib 5.6.49, for Linux (x86_64)
--
-- Host: localhost    Database: fh
-- ------------------------------------------------------
-- Server version	5.6.49-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `quan_rephost`
--

DROP TABLE IF EXISTS `quan_rephost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quan_rephost` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `year` varchar(255),
  `time` varchar(255),
  `number` varchar(255),
  `name` varchar(255),
  `url` varchar(255),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quan_rephost`
--

LOCK TABLES `quan_rephost` WRITE;
/*!40000 ALTER TABLE `quan_rephost` DISABLE KEYS */;
INSERT INTO `quan_rephost` VALUES ('1','','','','','');
/*!40000 ALTER TABLE `quan_rephost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quan_config`
--

DROP TABLE IF EXISTS `quan_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quan_config` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `user` varchar(250) NOT NULL,
  `pwd` varchar(250) NOT NULL,
  `sitename` varchar(50) NOT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `template` varchar(2550) DEFAULT NULL,
  `kfqq` varchar(20) NOT NULL,
  `announcement` text NOT NULL,
  `bottom` text NOT NULL,
  `beian` text NOT NULL,
  `pagename`varchar(150)  NOT NULL,
  `sign` varchar(150)  NOT NULL,
  `statecolor`varchar(150)  NOT NULL,
  `state` varchar(150)  NOT NULL,
  `emoji` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `sitetext` varchar(150)  NOT NULL,
  `edition`varchar(150)  NOT NULL,
  `forward` varchar(150)  NOT NULL,
  `author` varchar(150) NOT NULL,
  `skill1` varchar(150) NOT NULL,
  `skill2` varchar(150)  NOT NULL,
  `skill3`varchar(150)  NOT NULL,
  `skill4` varchar(150)  NOT NULL,
  `fate` varchar(150) NOT NULL,
  `mcover` varchar(150) NOT NULL,
  `mlink` varchar(150) NOT NULL,
  `zan` varchar(150)  NOT NULL,
  `tul1`varchar(150)  NOT NULL,
  `tula1` varchar(150)  NOT NULL,
  `tul2` varchar(150) NOT NULL,
  `tula2` varchar(150) NOT NULL,
  `tul3` varchar(150)  NOT NULL,
  `tula3`varchar(150)  NOT NULL,
  `tul4` varchar(150)  NOT NULL,
  `tula4` varchar(150) NOT NULL,
  `tul5` varchar(150)  NOT NULL,
  `tula5` varchar(150) NOT NULL,
  `tul6` varchar(150)  NOT NULL,
  `tula6` varchar(150) NOT NULL,
  `tul7` varchar(150)  NOT NULL,
  `tula7` varchar(150) NOT NULL,
  `tulam7` varchar(150) NOT NULL,
  `sjt1` varchar(150)  NOT NULL,
  `sjtl1` varchar(150) NOT NULL,
  `sjt2` varchar(150)  NOT NULL,
  `sjtl2` varchar(150) NOT NULL,
  `sjt3` varchar(150)  NOT NULL,
  `sjtl3` varchar(150) NOT NULL,
  `sjt4` varchar(150)  NOT NULL,
  `sjtl4` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quan_config`
--

LOCK TABLES `quan_config` WRITE;
/*!40000 ALTER TABLE `quan_config` DISABLE KEYS */;
INSERT INTO `quan_config` VALUES (1,'admin','123456','尘屿小站','尘屿小站','尘屿小站','01','','','','','Chen Yu','天黑了.别忘记回家','#1de189','在线','1F602','iPhone','','v2.0','一切皆有可能','尘屿','GO','CSS','JS','PHP','1/7/2020','https://p1.music.126.net/AYNBdRxJ8EdZo4xFjp7b4Q==/109951163191178425.jpg','https://music.163.com/song/media/outer/url?id=2099010964.mp3','','fa-solid fa-house','','fa-solid fa-pen','','fa-solid fa-music','','fa-solid fa-cloud','','../assets/index/img/github-alt.svg','','../assets/index/img/octopus-deploy.svg','','../assets/index/img/cy.png','','SBIS','fa-brands fa-qq','','fa-brands fa-facebook','','fa-brands fa-twitter','','fa-brands fa-github','');
/*!40000 ALTER TABLE `quan_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `quan_nav`
--

DROP TABLE IF EXISTS `quan_nav`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quan_nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL ,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quan_nav`
--

LOCK TABLES `quan_nav` WRITE;
/*!40000 ALTER TABLE `quan_nav` DISABLE KEYS */;
INSERT INTO `quan_nav` VALUES('1','','');
/*!40000 ALTER TABLE `quan_nav` ENABLE KEYS */;
UNLOCK TABLES;



/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-10 15:50:38
