<!doctype html>
<!--作者：尘屿 -->
<html lang="en">
<head>
    <meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <title><?php echo $conf['sitename']; ?></title>
    <meta name="description" content="<?php echo $conf['description']; ?>">
    <meta name="keywords" content="<?php echo $conf['keywords']; ?>">
    <link rel="icon" type="/ico" href="/favicon.ico">
    <script charset="UTF-8" id="LA_COLLECT" src="//sdk.51.la/js-sdk-pro.min.js"></script>
    <script>LA.init({id:"KQVVHdqjpl0T69D1",ck:"KQVVHdqjpl0T69D1"})</script>
    <link rel="stylesheet" href="../assets/index/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.staticfile.net/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/index/css/animate.min.css">
    
    <link rel="stylesheet" href="../assets/index/css/style.css">
    <link href="https://fonts.googlefonts.cn/css?family=Capriola" rel="stylesheet">



    <script>
      $(document).ready(function(){
        $('.toast').toast('show');
      });
    </script>
    


<style>
body {
  position: relative;
  background-attachment: fixed;
  background-repeat: no-repeat;
  min-height: 690px;
  background-size: 100%;
  background: var(--dark-mode-body, linear-gradient(120deg, #f7cddb,#add2f1)no-repeat);
  color: var(--dark-mode-text-color,#141414);
}
body.dark-mode{
    --dark-mode-text-color:rgb(245, 245, 245);
    --dark-mode-body:#3d3d3d;
    --dark-mode-wybody:#272731;
    --dark-mode-wymbody:#1d1c22;
    --dark-mode-wytext:#66676f;
    --dark-mode-toggle-translate:15px;
    --dark-mode-body1:url(../assets/index/img/moon-solid.svg);
    
}
.mode-switch__circle{
    height: 15px;
    width: 15px;
    border-radius: 100px;
    background:var(--dark-mode-body1,url(../assets/index/img/sun-regular.svg));
    transform: translateX(var(--dark-mode-toggle-translate,0));
    transition: transfore 0.3s ease;
    pointer-events: none;
    transition: 0.4s;
}    

</style>
</head>

<body>
  <div class="toast animate__animated animate__pulse" role="alert" aria-live="assertive" aria-atomic="true" data-delay="1500">
    <div class="toast-body">
      <span><?php echo $conf['announcement']; ?></span>
    </div>
  </div>
  <div class="container">
    <div class="row justify-content-center">
      <div class="left">
        
        <div class="flex-container">
          <div><img src="https://imgapi.cn/qq.php?qq=<?php echo $conf['kfqq']; ?>" class="touxi"></div>
          <div class="gexing">
            <div class="flex-container">
              <div class="toem"><?php echo $conf['pagename']; ?></div>
            </div>
            <div class="flex-container">
              <div class="sign"><?php echo $conf['sign']; ?></div>
            </div>
            <div class="flex-container">
              <div class="state"><div class="state1"><i class="fa-solid fa-circle fa-2xs" style="color: <?php echo $conf['statecolor']; ?>;"></i></div><div class="state2">&nbsp;<?php echo $conf['phone']; ?>&nbsp;<?php echo $conf['state']; ?>&nbsp;</div>&#x<?php echo $conf['emoji']; ?></div>
            </div>
          </div>
          <div><button type="button" class="btn btn-link" data-toggle="modal" data-target="#exampleModal" style=" margin: 35px 0 0 25px; color: var(--dark-mode-text-color,#141414);"><i class="fa-solid fa-qrcode fa-lg"></i></button>
          </div>  
        </div>
            <hr style="margin: 0; margin-top: 10px; margin-bottom: 10px;">
            <div class="flex-container justify-content-center" style="width:auto;">
                
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #f70808;"></i>&nbsp;<?php echo $conf['skill1']; ?>&nbsp;</div>
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #63e6be;"></i>&nbsp;<?php echo $conf['skill2']; ?>&nbsp;</div>
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #74C0FC;"></i>&nbsp;<?php echo $conf['skill3']; ?>&nbsp;</div>
              <div class="neckbtn">&nbsp;<i class="fa-solid fa-circle-check" style="color: #ea875e;"></i>&nbsp;<?php echo $conf['skill4']; ?>&nbsp;</div>
            </div>

        <div class="row justify-content-center">
          <div class="left-4-1 animate__animated animate__pulse">
            <span>
              <img src="<?php echo $conf['mcover']; ?>" style="width: 33px;height: 33px;border-radius: 6px;margin: 5px 0 0 5px;">
              <div class="sh-main-top-mu" lang="0" onclick="syaudbf()"><i class="fa-regular fa-circle-play fa-lg" id="sh-main-top-mu" lang="0" data-bfzt="bb"></i></div>
            </span>
            <div id="sh-main-top-g-m" class="sh-main-top-g-containe" lang="在你的身边">
              <div id="sh-main-top-mucisjd" lang="0" style="display:none;">
                  <div class="shaft-load2">
                  <div class="shaft1"></div>
                  <div class="shaft2"></div>
                  <div class="shaft3"></div>
                  <div class="shaft4"></div>
                  <div class="shaft5"></div>
                  <div class="shaft6"></div>
                  <div class="shaft7"></div>
                  <div class="shaft8"></div>
                  <div class="shaft9"></div>
                  <div class="shaft10"></div>
                  <div class="shaft11"></div>
                  <div class="shaft12"></div>
                  <div class="shaft13"></div>
                  <div class="shaft14"></div>
                  <div class="shaft15"></div>
                  <div class="shaft16"></div>
                  <div class="shaft17"></div>
                  <div class="shaft18"></div>
                  <div class="shaft19"></div>
                  <div class="shaft20"></div>
                  </div>
              </div>
            </div>
            <audio id="sh-main-top-musicplay-b" src="<?php echo $conf['mlink']; ?>" type="audio/mp3" controls="controls" style="display: none;"></audio>
            <audio id="musicplay" src="" type="audio/mp3" controls="controls" style="display: none;" lang="0" class="">您的浏览器不支持音频元素。</audio>   
          </div>
          <button type="button" class="left-4-2" data-toggle="modal" data-target="#exampleModa4" style="color: var(--dark-mode-text-color,#141414);border:none;"><img src="../assets/index/img/wyy.svg"></button>
          <button class="btn btn-link animate__animated animate__pulse" type="button" data-toggle="collapse" data-target="#coll" aria-expanded="false" aria-controls="coll"style="margin-left: 7px;margin-top: 20px;width: 50px;height: 50px;border-radius: 10px;padding-bottom: 10px;background: var(--dark-mode-body,#fefefe);margin-bottom: 10px;float: left;">
            <i class="fa-solid fa-bars fa-lg"></i></button>
          <div class="left-4-4 animate__animated animate__pulse"><img src="../assets/index/img/China.svg"></div>
          <div class="collapse" id="coll" >
            <div class="card card-body" style="border-radius: 10px; display: inline-block; height: 40px; padding: 0; background: var(--dark-mode-body,#fefefe);">
              <button type="button" class="btn btn-link" data-toggle="modal" data-target="#site"><img src="../assets/index/img/globe.svg" style="width: 25px;height: 25px;"></button>
              <button onclick="switchSakura()" class="btn btn-link"><i class="fa-regular fa-circle-xmark fa-lg "style="color: pink;"></i></button>
              <button type="button" class="btn btn-link" data-toggle="modal" data-target="#about"><img src="../assets/index/img/information.svg" style="width: 25;height: 25px;"></button>
            </div>
          </div>
          
        </div>

        <div class="flex-container justify-content-center">
          <div class="applesb animate__animated animate__pulse">
            <div class="flex-container justify-content-center">
              <a href="<?php echo $conf['tula1']; ?>" class="applesb-1"><i class="<?php echo $conf['tul1']; ?>"></i></a>
              <a href="<?php echo $conf['tula2']; ?>" class="applesb-1"><i class="<?php echo $conf['tul2']; ?>"></i></a>
            </div>
            <div class="flex-container justify-content-center">
              <a href="<?php echo $conf['tula3']; ?>" class="applesb-1"><i class="<?php echo $conf['tul3']; ?>"></i></a>
              <a href="<?php echo $conf['tula4']; ?>" class="applesb-1"><i class="<?php echo $conf['tul4']; ?>"></i></a>
            </div>
          </div>
          <div class="applesb">
            <div class="flex-container justify-content-center animate__animated animate__pulse">
              <a href="<?php echo $conf['tula5']; ?>" class="applesb-2"><img src="<?php echo $conf['tul5']; ?>"></a>
              <a href="<?php echo $conf['tula6']; ?>" class="applesb-2"><img src="<?php echo $conf['tul6']; ?>"></a>
            </div>
            <div class="flex-container justify-content-center">
              <a href="<?php echo $conf['tula7']; ?>" class="applesb-3"><img src="<?php echo $conf['tul7']; ?>">&nbsp;<?php echo $conf['tulam7']; ?></a>
            </div>
          </div>
        </div>

        <div class="slide-bar">
            <?php 
            $sql = $DB->query("SELECT * FROM `quan_nav` ORDER BY id DESC");
            while ($res = $DB->fetch($sql)) {
                echo '<div class="slide-centent"><a href="' . htmlspecialchars($res['domain']) . '">';
                echo '' . htmlspecialchars($res['type']) . '</a></div>';
               
            }
            ?>
        </div>
 
        <div class="flex-container justify-content-center">
          <div class="left-3 animate__animated animate__pulse">
            <a href="<?php echo $conf['sjtl1']; ?>"><i class="<?php echo $conf['sjt1']; ?>" style="color:#a0d5ff;"></i></a>
            <a href="<?php echo $conf['sjtl2']; ?>"><i class="<?php echo $conf['sjt2']; ?>" style="color:#ffc19c;"></i></a>
            <a href="<?php echo $conf['sjtl3']; ?>"><i class="<?php echo $conf['sjt3']; ?>" style="color: black;"></i></a>
            <a href="<?php echo $conf['sjtl4']; ?>"><i class="<?php echo $conf['sjt4']; ?>" style="color:pink;"></i></a>
          </div>
          <div class="left-3-2 animate__animated animate__pulse">
            <div class="mode-switch">
              <div class="mode-switch__toggle">
              <div class="mode-switch__circle">
              </div></div>
            </div>
          </div>
          <div class="left-3-3 animate__animated animate__pulse">
            <a href="/admin"><i class="fa-regular fa-circle-user fa-lg"></i></a>
          </div>
        </div>

      </div>
     </div>

        

      <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered row justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border-radius: 10px; background: var(--dark-mode-body,#f2f1f6); width: 233px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><i class="fa-solid fa-quote-left" style="color: #fb7474;"></i>&nbsp;赞赏框&nbsp;<i class="fa-solid fa-quote-right" style="color: #fb7474;"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <img src="<?php echo $conf['zan']; ?>" class="zanshang">
            </div>
          </div>
        </div>
      </div>
      
      <div class="modal fade" id="exampleModa4" tabindex="-1" aria-labelledby="exampleModalLabe4" aria-hidden="true">
        <div class="modal-dialog modal-dialog-scrollable justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border:none;border-radius: 10px; background: var(--dark-mode-wymbody,#f2f1f6); width: 300px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabe4"><i class="fa-solid fa-quote-left" style="color: #fb7474;"></i>&nbsp;网易云年度报告&nbsp;<i class="fa-solid fa-quote-right" style="color: #fb7474;"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                 <?php 
            $sql = $DB->query("SELECT * FROM `quan_rephost` ORDER BY id DESC");
            while ($res = $DB->fetch($sql)) {
                echo '<h1 style="text-align:center;background: linear-gradient(to bottom,#ff0000,#e82626, #ee4444, #ff7a7a);
    -webkit-background-clip: text; 
    -webkit-text-fill-color: transparent;margin:0;">' . htmlspecialchars($res['year']) . '</h1>';
                echo '<div class="wwy2023"style="padding:5px;background:var(--dark-mode-wybody,#ffffff);border-radius:15px;box-shadow: 0 0 25px 0.5px rgba(0, 0, 0, 0.05);">
                      <div class="flex-container"style="display:flex;justify-content:space-between;margin: 15px 30px 0;">
                          <strong style="font-size:12px;color:#ff3839;">听歌时长</strong>
                          
                          <strong style="font-size:12px;color:#ff3839;">听歌总数</strong>
                      </div>
                
                      <div class="flex-container"style="display:flex;justify-content:space-between;margin:0 25px">
                          <div style="font-size:25px;">' . htmlspecialchars($res['time']) . 'H</div>';
                echo '<div style="font-size:25px;">' . htmlspecialchars($res['number']) . '首</div>
                      </div>
                  <hr/>';
                echo '<div class="flex-container"style="display:flex;">
                      <img style="width:90px;height:60px;border-radius:5px;margin:0 5px 5px 5px" src="' . htmlspecialchars($res['url']) . '">';
                echo '<div style="font-size:14px;align-items:center;display:flex;color:var(--dark-mode-wytext,#27334b);font-weight:bold">' . htmlspecialchars($res['name']) . '</div>
                  </div>
              </div>
              <br>';
            }
            ?>
              
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="about" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border-radius: 10px; background: var(--dark-mode-body,#f2f1f6); width: 280px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><i class="fa-solid fa-quote-left" style="color: #74C0FC;"></i>&nbsp;关于&nbsp;<i class="fa-solid fa-quote-right" style="color: #74C0FC"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <span><i class="fa-regular fa-note-sticky" style="color:#74C0FC;">&nbsp;</i>&nbsp;<?php echo $conf['edition']; ?></span>
              <hr>
              <span><i class="fa-regular fa-comment" style="color: #63e6be;">&nbsp;</i>&nbsp;<?php echo $conf['forward']; ?></span>
              <hr>
              <span><i class="fa-regular fa-user">&nbsp;</i>&nbsp;<?php echo $conf['author']; ?></span>
              <hr>
              <span><i class="fa-regular fa-circle-down" style="color: #B197FC;">&nbsp;</i>&nbsp;</i>&nbsp;<a href="https://chyu.lanzout.com/i1UXe1ylu15i">源码下载</a></span>
            </div>
          </div>
        </div>
      </div>

      <div class="modal fade" id="site" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered justify-content-center">
          <div class="modal-content animate__animated animate__pulse" style="border-radius: 10px; background: var(--dark-mode-body,#f2f1f6); width: 250px;">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel"><i class="fa-solid fa-quote-left" style="color: #74C0FC;"></i>&nbsp;旗下站点&nbsp;<i class="fa-solid fa-quote-right" style="color: #74C0FC"></i></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <div class="sitetext"><?php echo $conf['sitetext']; ?></div>
            </div>
          </div>
        </div>
      </div>

    </div>
    <footer class="fixed-booten">
      <div id="runtime_span" class="runtime"></div>
      <script>function show_runtime(){window.setTimeout("show_runtime()",1000);X=new 
        Date("<?php echo $conf['fate']; ?> 00:00:00");
        Y=new Date();T=(Y.getTime()-X.getTime());M=24*60*60*1000;
        a=T/M;A=Math.floor(a);b=(a-A)*24;B=Math.floor(b);c=(b-B)*60;C=Math.floor((b-B)*60);D=Math.floor((c-C)*60);
        runtime_span.innerHTML="已运行:&nbsp;"+A+"&nbsp;天&nbsp;"+B+"&nbsp;小时&nbsp;"+C+"&nbsp;分&nbsp;"+D+"&nbsp;秒"}show_runtime();
      </script>
      <div class="by"><?php echo $conf['bottom']; ?></div>
      <div class="by"><i class="fa-regular fa-copyright fa-sm"></i>&nbsp;2024&nbsp;尘屿小站&nbsp;|&nbsp;Designed&nbsp;by<a href="https://qm.qq.com/cgi-bin/qm/qr?k=DqHOrWELY4YSowdC6lnyvS9Cd8b1ufSi" style="text-decoration: none;">&nbsp;ChenYu</a></div>
      <div class="body-bottom">
        <a href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank"><img src="../assets/index/img/icp.svg"><?php echo $conf['beian']; ?></a>
      </div>
    </footer>
    
</body>
<script src="../assets/index/js/jquery-3.5.1.min.js"></script>
    <script src="../assets/index/js/bootstrap.min.js"></script>
    <script src="../assets/index/js/player.js"></script>
    <script src="../assets/index/js/dark.js"></script>
    <script src="../assets/index/js/jquery.min.js"></script>
</html>