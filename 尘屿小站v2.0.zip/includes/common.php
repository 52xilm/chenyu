<?php
error_reporting(0);
define('IN_CRONLITE', true);
define('SYSTEM_ROOT', dirname(__FILE__).'/');
define('ROOT', dirname(SYSTEM_ROOT).'/');
date_default_timezone_set("PRC");
define('VERSION', 'v1.5.6');
$date = date("Y-m-j H:i:s");
session_start();
//数据库配置文件
require ROOT . 'config.php';
//检查配置文件
 if(!defined('SQLITE') && (!$dbconfig['user']||!$dbconfig['pwd']||!$dbconfig['dbname'])){header('Content-type:text/html;charset=utf-8');echo '你还没安装！<a href="../install/">点此安装</a>';exit();}
//mysql操作类
include_once (SYSTEM_ROOT . "lib/a.php");
//开始连接数据库
$DB=new DB($dbconfig['host'],$dbconfig['user'],$dbconfig['pwd'],$dbconfig['dbname'],$dbconfig['port']);
if($DB->query("select * from quan_config where 1")==FALSE){header('Content-type:text/html;charset=utf-8');echo '<div class="row">你还没安装！<a href="../install">点此安装</a></div>';exit();}

if(!file_exists(ROOT . 'install/install.lock')){ header('Content-type:text/html;charset=utf-8');echo '<div class="row">没有install.lock文件！<a href="../install/">点此安装</a></div>';exit();}
//获取系统配置
$conf=$DB->get_row("SELECT * FROM quan_config WHERE id=1 limit 1");
//其他功能
$password_hash='!@#%!s!0';
include_once(SYSTEM_ROOT."lib/b.php");
include_once(SYSTEM_ROOT."lib/c.php");
$nav=$DB->count("SELECT count(*) from quan_nav WHERE 1");
$img=$DB->count("SELECT count(*) from quan_img WHERE 1");
$top=$DB->count("SELECT count(*) from quan_top WHERE 1");
$other=$DB->count("SELECT count(*) from quan_other WHERE 1");
$rephost=$DB->count("SELECT count(*) from quan_rephost WHERE 1");
$dwz=$DB->count("SELECT sum(time) FROM quan_long");
?>