<?php
include './includes/common.php';
include './template/index/'.$conf['template'].'/index.php';
?>