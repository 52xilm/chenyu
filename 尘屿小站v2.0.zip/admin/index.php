<?php
$act=$_GET['act'];
include_once '../includes/common.php';
if($islogin!=1){
exit("<script language='javascript'>window.location.href='./login.php';</script>");
}
if($act=='set'){
$title='网站配置';
}elseif($act=='ztsz'){
$title='主题配置';
}elseif($act=='host' && $my='add'){
$title='友链导航';
}elseif($act=='host'){
$title='友链列表';
}elseif($act=='report'){
$title='音乐报告';
}elseif($act=='report' &&$my=='add'){
$title='报告列表';
}elseif($act=='other'){
$title='其他配置';
}elseif($act=='img'){
$title='图链配置';
}elseif($act=='top'){
$title='头部配置';
}elseif($act=='pass'){
$title='修改密码';
}else{
$title='管理中心';
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title><?php echo $title ?></title>
<link rel="icon" href="/favicon.ico" type="image/ico">
<link href="/assets/LightYear/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/materialdesignicons.min.css" rel="stylesheet">
<link href="/assets/LightYear/css/style.min.css" rel="stylesheet">
<script type="text/javascript" src="/assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="/assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript" src="/assets/LightYear/js/perfect-scrollbar.min.js"></script>
<script type="text/javascript" src="/assets/LightYear/js/main.min.js"></script>
<script type="text/javascript" src="https://cdn.staticfile.net/layer/3.5.1/layer.js"></script>
</head>

<script language="javascript">
function logout(){
layer.alert('你确定要退出吗？',{title:'温馨提示'},function(){window.location.href='login.php?logout'});
}
</script>

<body>
<div class="lyear-layout-web">
  <div class="lyear-layout-container">
    <aside class="lyear-layout-sidebar">
      <div id="logo" class="sidebar-header">
        <a href="index.php"><img src="/assets/img/logo-sidebar.png" height="75px"/></a>
      </div>
      <div class="lyear-layout-sidebar-scroll"> 
        <nav class="sidebar-main">
          <ul class="nav nav-drawer">
            <li class="nav-item">
                <a href="index.php"><i class="mdi mdi-home"></i>后台首页</a> </li>
            <li class="nav-item">
                <a href="index.php?act=top"><i class="mdi mdi-monitor"></i>头部配置</a> </li>
            <li class="nav-item"> 
                <a href="index.php?act=img"><i class="mdi mdi-image"></i>图链配置</a> </li>
            <li class="nav-item">
                <a href="index.php?act=host&my=add"><i class="mdi mdi-link"></i>友链导航</a> </li>
            <li class="nav-item">
                <a href="index.php?act=report&my=add"><i class="mdi mdi-file-chart"></i>音乐报告</a> </li>
            <li class="nav-item ">
                <a href="index.php?act=ztsz"><i class="mdi mdi-tshirt-crew"></i>主题配置</a> </li>
            <li class="nav-item">
                <a href="index.php?act=set"><i class="mdi mdi-web"></i>网站配置</a> </li>
            <li class="nav-item">
                <a href="index.php?act=other"><i class="mdi mdi-alert-circle-outline"></i>其他配置</a> </li>
                
          </ul>
        </nav>
        <div class="sidebar-footer">
          <p class="copyright">Copyright &copy; 2024. <a target="_blank" href=""><?php echo $conf['sitename']; ?></a> All rights reserved.</p>
        </div>
      </div>
    </aside>
    
    
    <header class="lyear-layout-header">
      <nav class="navbar navbar-default">
        <div class="topbar">
          <div class="topbar-left">
            <div class="lyear-aside-toggler">
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
              <span class="lyear-toggler-bar"></span>
            </div>
            <span class="navbar-page-title"> 后台首页 </span>
          </div>
           <ul class="topbar-right">
            <li class="dropdown dropdown-profile">
              <a href="javascript:void(0)" data-toggle="dropdown">
                <img class="img-avatar img-avatar-48 m-r-10" src="https://q4.qlogo.cn/headimg_dl?dst_uin=<?php echo $conf['kfqq'];?>&amp;spec=100" alt="<?php echo $conf['sitename']; ?>" />
                <span>个人中心<span class="caret"></span></span>
              </a>
               <ul class="dropdown-menu dropdown-menu-right">
                <li> <a href="index.php?act=set"><i class="mdi mdi-account"></i> 网站信息</a> </li>
                <li> <a href="index.php?act=pass"><i class="mdi mdi-lock-outline"></i> 修改密码</a> </li>
                <li class="divider"></li>
                <li> <a href="javascript:logout()"><i class="mdi mdi-logout-variant"></i> 退出登录</a> </li>
              </ul>
           </ul>
          </li>
        </ul>
        
      </nav>
      
    </header>








<?php if($_GET['act']=="img")
{
?>
    
    <main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">图链配置</a> </li>
              </ul>
<div class="tab-content">
<div class="tab-pane active">
    <?php
if(isset($_POST['imgsubmit'])) {
   $mcover=daddslashes($_POST['mcover']);
   $mlink=daddslashes($_POST['mlink']);
    $zan=daddslashes($_POST['zan']);
    $tul1=daddslashes($_POST['tul1']);
    $tula1=daddslashes($_POST['tula1']);
    $tul2=daddslashes($_POST['tul2']);
    $tula2=daddslashes($_POST['tula2']);
    $tul3=daddslashes($_POST['tul3']);
    $tula3=daddslashes($_POST['tula3']);
    $tul4=daddslashes($_POST['tul4']);
    $tula4=daddslashes($_POST['tula4']);
    $tul5=daddslashes($_POST['tul5']);
    $tula5=daddslashes($_POST['tula5']);
    $tul6=daddslashes($_POST['tul6']);
    $tula6=daddslashes($_POST['tula6']);
    $tul7=daddslashes($_POST['tul7']);
    $tula7=daddslashes($_POST['tula7']);
    $tulam7=daddslashes($_POST['tulam7']);
    $sjt1=daddslashes($_POST['sjt1']);
    $sjtl1=daddslashes($_POST['sjl1']);
    $sjt2=daddslashes($_POST['sjt2']);
    $sjtl2=daddslashes($_POST['sjl2']);
    $sjt3=daddslashes($_POST['sjt3']);
    $sjtl3=daddslashes($_POST['sjl3']);
    $sjt4=daddslashes($_POST['sjt4']);
    $sjtl4=daddslashes($_POST['sjl4']);
    $sql="UPDATE `quan_config` SET `mcover` = '$mcover', `mlink` = '$mlink', `zan` = '$zan', `tul1` = '$tul1', `tula1` = '$tula1', `tul2` = '$tul2', `tula2` = '$tula2',  `tul3` = '$tul3', `tula3` = '$tula3',  `tul4` = '$tul4', `tula4` = '$tula4',  `tul5` = '$tul5', `tula5` = '$tula5', `tul6` = '$tul6', `tula6` = '$tula6', `tul7` = '$tul7',`tula7` = '$tula7',`tulam7` = '$tulam7',`sjt1` = '$sjt1',`sjtl1` = '$sjtl1',`sjt2` = '$sjt2',`sjtl2` = '$sjtl2',`sjt3` = '$sjt3',`sjtl3` = '$sjtl3',`sjt4` = '$sjt4',`sjtl4` = '$sjtl4' WHERE `quan_config`.`id` = 1";
    if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('修改成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=img'});</script>");
  }
  else
  	exit("<script type='text/javascript'>layer.alert('修改失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=img'});</script>");
  }
?>
<div class="panel-body">
  <form action="index.php?act=img" method="post" class="form-horizontal" role="form">
    		<div class="form-group">
	  <label class="col-xs-12">音乐图链</label>
	  <div class="col-xs-12"><input type="text" placeholder="图片" name="mcover" value="<?php echo $conf['mcover']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text" placeholder="链接" name="mlink" value="<?php echo $conf['mlink']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12 ">赞赏码</label>
	  <div class="col-xs-12"><input type="text" name="zan" value="<?php echo $conf['zan']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12 ">导航图链1</label>
	  <small class="help-block">参考<a href="https://fontawesome.com/search?m=free&o=r">FontAwesome</a>
	  图片：<code>fa-solid fa-house</code></small>
	  <div class="col-xs-12"><input type="text" placeholder="图片" name="tul1" value="<?php echo $conf['tul1']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula1" value="<?php echo $conf['tula1']; ?>" class="form-control border-input"/></div>
	</div><br/>
			<div class="form-group">
	  <label class="col-xs-12 ">导航图链2</label>
	  <small class="help-block">图片：<code>fa-solid fa-house</code></small>
	  <div class="col-xs-12"><input type="text" placeholder="图片" name="tul2" value="<?php echo $conf['tul2']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula2" value="<?php echo $conf['tula2']; ?>" class="form-control border-input"/></div>
	</div><br/>
            <div class="form-group">
	  <label class="col-xs-12 ">导航图链3</label>
	  <small class="help-block">图片：<code>fa-solid fa-house</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="tul3" value="<?php echo $conf['tul3']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula3" value="<?php echo $conf['tula3']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">导航图链4</label>
	  <small class="help-block">图片：<code>fa-solid fa-house</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="tul4" value="<?php echo $conf['tul4']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula4" value="<?php echo $conf['tula4']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">导航图链5</label>
	  <small class="help-block"><code>请填写图片链接</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="tul5" value="<?php echo $conf['tul5']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula5" value="<?php echo $conf['tula5']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">导航图链6</label>
	  <small class="help-block"><code>请填写图片链接</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="tul6" value="<?php echo $conf['tul6']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula6" value="<?php echo $conf['tula6']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">导航图链7</label>
	  <small class="help-block"><code>请填写图片链接</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="tul7" value="<?php echo $conf['tul7']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="tula7" value="<?php echo $conf['tula7']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="名称" name="tulam7" value="<?php echo $conf['tulam7']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">社交联系1</label>
	  <small class="help-block">图片：<code>fa-brands fa-qq</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="sjt1" value="<?php echo $conf['sjt1']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="sjtl1" value="<?php echo $conf['sjtl1']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">社交联系2</label>
	  <small class="help-block">图片：<code>fa-brands fa-twitter</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="sjt2" value="<?php echo $conf['sjt2']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="sjtl2" value="<?php echo $conf['sjtl2']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">社交联系3</label>
	  <small class="help-block">图片：<code>fa-brands fa-facebook</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="sjt3" value="<?php echo $conf['sjt3']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="sjtl3" value="<?php echo $conf['sjtl3']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">社交联系4</label>
	  <small class="help-block">图片：<code>fa-brands fa-github</code></small>
	  <div class="col-xs-12"><input type="text"placeholder="图片" name="sjt4" value="<?php echo $conf['sjt4']; ?>" class="form-control border-input"/></div>
	  <div class="col-xs-12"><input type="text"placeholder="链接" name="sjtl4" value="<?php echo $conf['sjtl4']; ?>" class="form-control border-input"/></div>
	</div><br/>
	
                  
                  

	<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="imgsubmit" value="修改" class="btn btn-info btn-fill btn-block" style="border-radius:10px;"/>
	 </div>
	</div>
  </form>
</div>
</div>

      </div>
      </div>
      






<?php }elseif($_GET['act']=="other"){?>
    
    
    <main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">其他配置</a> </li>
              </ul>
<div class="tab-content">
<div class="tab-pane active">
    <?php
if(isset($_POST['othersubmit'])) {
   $sitetext=daddslashes($_POST['sitetext']);
    $edition=daddslashes($_POST['edition']);
    $forward=daddslashes($_POST['forward']);
    $author=daddslashes($_POST['author']);
    $skill1=daddslashes($_POST['skill1']);
    $skill2=daddslashes($_POST['skill2']);
    $skill3=daddslashes($_POST['skill3']);
    $skill4=daddslashes($_POST['skill4']);
    $fate=daddslashes($_POST['fate']);
    $sql="UPDATE `quan_config` SET `sitetext` = '$sitetext', `edition` = '$edition', `forward` = '$forward', `author` = '$author', `skill1` = '$skill1', `skill2` = '$skill2',  `skill3` = '$skill3', `skill4` = '$skill4', `fate` = '$fate' WHERE `quan_config`.`id` = 1";
    if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('修改成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=other'});</script>");
  }
  else
  	exit("<script type='text/javascript'>layer.alert('修改失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=other'});</script>");
  }
?>
<div class="panel-body">
  <form action="index.php?act=other" method="post" class="form-horizontal" role="form">
	<div class="form-group">
                    <label class="col-xs-12" for="example-textarea-input">旗下站点</label>
                    <div class="col-xs-12">
                      <textarea class="form-control" id="example-textarea-input" name="sitetext" rows="5" placeholder="输入旗下站点"><?php echo $conf['sitetext'];?></textarea>
                    </div>
                  </div></br>
    		<div class="form-group">
	  <label class="col-xs-12 ">版本</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入版本号" name="edition" value="<?php echo $conf['edition']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12 ">引言</label>
	  <div class="col-xs-12"><input type="text"placeholder="输入引言" name="forward" value="<?php echo $conf['forward']; ?>" class="form-control border-input"/></div>
	</div><br/>
			<div class="form-group">
	  <label class="col-xs-12 ">作者</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入作者" name="author" value="<?php echo $conf['author']; ?>" class="form-control border-input"/></div>
	</div><br/>

     <div class="form-group">
	  <label class="col-xs-12 ">技能1</label>
	  <div class="col-xs-12"><input type="text" placeholder="HTML" name="skill1" value="<?php echo $conf['skill1']; ?>" class="form-control border-input"/></div>
	</div><br/>

     <div class="form-group">
	  <label class="col-xs-12 ">技能2</label>
	  <div class="col-xs-12"><input type="text"placeholder="CSS" name="skill2" value="<?php echo $conf['skill2']; ?>" class="form-control border-input"/></div>
	</div><br/>
                 <div class="form-group">
	  <label class="col-xs-12 ">技能3</label>
	  <div class="col-xs-12"><input type="text" placeholder="JS" name="skill3" value="<?php echo $conf['skill3']; ?>" class="form-control border-input"/></div>
	</div><br/>
	
	<div class="form-group">
	  <label class="col-xs-12 ">技能4</label>
	  <div class="col-xs-12"><input type="text" placeholder="PHP" name="skill4" value="<?php echo $conf['skill4']; ?>" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-xs-12 ">运行天数</label>
	  <div class="col-xs-12"><input type="text" name="fate" value="<?php echo $conf['fate']; ?>" placeholder="格式:1/7/2020" class="form-control border-input"/></div>
	</div><br/>
                  

	<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="othersubmit" value="修改" class="btn btn-info btn-fill btn-block" style="border-radius:10px;"/>
	 </div>
	</div>
  </form>
</div>
</div>

      </div>
      </div>
    




<?php } elseif($_GET['act']=="top"){?>


<main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">头部配置</a> </li>
              </ul>
<div class="tab-content">
<div class="tab-pane active">
       <?php
if(isset($_POST['topsubmit'])) {
   $pagename=daddslashes($_POST['pagename']);
    $sign=daddslashes($_POST['sign']);
    $statecolor=daddslashes($_POST['statecolor']);
    $state=daddslashes($_POST['state']);
        $emoji=daddslashes($_POST['emoji']);
        $phone=daddslashes($_POST['phone']);
    $sql="UPDATE `quan_config` SET `pagename` = '$pagename', `sign` = '$sign', `statecolor` = '$statecolor', `state` = '$state', `emoji` = '$emoji', `phone` = '$phone' WHERE `quan_config`.id='1'";
    if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('修改成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=top'});</script>");
  }
  else
  	exit("<script type='text/javascript'>layer.alert('修改失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=top'});</script>");
  }
?>
<div class="panel-body">
  <form action="index.php?act=top" method="post" class="form-horizontal" role="form">
    		<div class="form-group">
	  <label class="col-xs-12">主页名称</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入主页名称" name="pagename" value="<?php echo $conf['pagename']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12 ">个性签名</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入个性签名" name="sign" value="<?php echo $conf['sign']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12 ">状态色</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入颜色代码" name="statecolor" value="<?php echo $conf['statecolor']; ?>" class="form-control border-input"/></div>
	</div><br/>
			<div class="form-group">
	  <label class="col-xs-12 ">状态</label>
	  <div class="col-xs-12"><input type="text" placeholder="在线" name="state" value="<?php echo $conf['state']; ?>" class="form-control border-input"/></div>
	</div><br/>

     <div class="form-group">
	  <label class="col-xs-12 ">Emoji</label>
	  <small class="help-block">字符编码：<code>1F602</code></small>
	  <div class="col-xs-12"><input type="text" name="emoji" value="<?php echo $conf['emoji']; ?>" class="form-control border-input"/></div>
	</div><br/>

     <div class="form-group">
	  <label class="col-xs-12 ">设备型号</label>
	  <div class="col-xs-12"><input type="text" placeholder="iPhone" name="phone" value="<?php echo $conf['phone']; ?>" class="form-control border-input"/></div>
	</div><br/>
                  
                  
	<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="topsubmit" value="修改" class="btn btn-info btn-fill btn-block" style="border-radius:10px;"/>
	 </div>
	</div>
  </form>
</div>
</div>

      </div>
      </div>







<?php } elseif($_GET['act']=="report"){?>


<main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">音乐报告</a> </li>
              </ul>
<div class="card-header"></div>
<div class="card-body">
<?php
if ($my == 'add') {
    $url = isset($_GET['url']) ? $_GET['url'] : '';
    $parsedUrl = parse_url($url);
    $urlHost = isset($parsedUrl['host']) ? $parsedUrl['host'] : '';

    echo '<form action="index.php?act=report&my=add_submit" method="POST">
    <div class="form-group">
    <label>年份:</label><br>
<input type="text" class="form-control" name="year" value="'.htmlspecialchars($urlHost, ENT_QUOTES, 'UTF-8').'" required>
    </div>
<div class="form-group">
<label>听歌时长:</label><br>
<input type="text" class="form-control" name="time" value="'.htmlspecialchars($urlHost, ENT_QUOTES, 'UTF-8').'" required>
</div>
<div class="form-group">
<label>歌曲数目:</label><br>
<input type="text" class="form-control" name="number" value="'.htmlspecialchars($urlHost, ENT_QUOTES, 'UTF-8').'" required>
</div>
<div class="form-group">
<label>标题:</label><br>
<input type="text" class="form-control" name="name" value="'.htmlspecialchars($urlHost, ENT_QUOTES, 'UTF-8').'" required>
</div>
<div class="form-group">
<label>图片链接:</label><br>
<input type="text" class="form-control" name="url" value="'.htmlspecialchars($urlHost, ENT_QUOTES, 'UTF-8').'" required>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定添加"></form>';
echo '<br/><a href="index.php?act=report">>>报告列表</a>';
echo '</div></div>';
}elseif($my=='add_submit'){
    $year=$_POST['year'];
  $time=$_POST['time'];
 $number=$_POST['number'];
 $name=$_POST['name'];
 $url=$_POST['url'];
  if($year==NULL or $time==NULL or $number==NULL or $name==NULL or $url==NULL){
    showmsg('保存错误,请确保每项都不为空!' , 'index.php?act=report&my=add' , 5 , 1 , 1000);;
  } else {
     
      $sql="INSERT INTO `quan_rephost` (`id`, `year`,`time`, `number`, `name`, `url`) VALUES (NULL,'$year', '$time', '$number', '$name', '$url');";

if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('添加成功".$DB->error()."',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=report'});</script>");
  }
  else{
  	exit("<script type='text/javascript'>layer.alert('添加失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=report'});</script>");
  }

  }
}elseif($my=='del'){
$id=intval($_GET['id']);
$sql=$DB->query("DELETE FROM quan_rephost WHERE id='$id'");
if($sql){
    exit("<script type='text/javascript'>layer.alert('删除成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=report'});</script>");
    
}
else{
    exit("<script type='text/javascript'>layer.alert('删除失败',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=report'});</script>");
    
}
    
}

elseif($my=='del2'){
$checkbox=$_POST['checkbox'];
$i=0;
foreach($checkbox as $id){
  $DB->query("DELETE FROM quan_rephost WHERE id='$id'");
  $i++;
}
exit("<script type='text/javascript'>layer.alert('成功删除{$i}个域名',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=report'});</script>");
}
else{
$numrows=$DB->count("SELECT count(*) from quan_rephost WHERE 1");
$sql=" 1";
$con='共有 <b>'.$numrows.'</b> 张报告';
$con.='&nbsp&nbsp<a href="index.php?act=report&my=add" class="btn btn-primary btn-sm">添加</a>';
echo $con;
?>
      <div class="table-responsive">
    <form name="form1" method="post" action="index.php?act=report&my=del2">
        <table class="table table-striped">
          <thead><tr><th>年份</th><th>听歌时长</th><th>歌曲数目</th><th>标题</th><th>图片链接</th></th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=10;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;


}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM quan_rephost WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
echo '<tr><td><input type="checkbox" name="checkbox[]" value="'.$res['id'].'"> '.htmlspecialchars($res['year']).'</td><td>'.$res['time'].'</td><td>'.$res['number'].'</td><td>'.$res['name'].'</td><td>'.$res['url'].'</td><td>'.$res['date'].'</td><td><a href="index.php?act=report&my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此记录吗？\');">删除</a></td></tr>';
}
?>
</table>
</table>
<input class="btn btn-xs btn btn-secondary" type="submit" name="Submit" value="删除选中">
</form>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="index.php?act=report&page='.$first.$link.'">首页</a></li>';
echo '<li><a href="index.php?act=report&page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="index.php?act=report&page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="index.php?act=report&page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="index.php?act=report&page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="index.php?act=report&page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>
    
    



<?php } elseif($_GET['act']=="host"){?>
    


<main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">友链导航</a> </li>
              </ul>
<div class="card-header"></div>
<div class="card-body">
<?php
$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add')
{
  if($url = $_GET['url']){
    $url = parse_url($url);
    $url = $url['host'];
  }
echo '<form action="index.php?act=host&my=add_submit" method="POST">
<div class="form-group">
<label>名称:</label><br>
<input type="text" class="form-control" name="type" value="'.$res['type'].'" required>
</div>
<div class="form-group">
<label>网址:</label><br>
<input type="text" placeholder="添加 https://、http://" class="form-control" name="domain" value="'.$res['domain'].'" required>
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定添加"></form>';
echo '<br/><a href="index.php?act=host">>>友链列表</a>';
echo '</div></div>';
}elseif($my=='add_submit'){
  $domain=$_POST['domain'];
  $type=$_POST['type'];
  if($domain==NULL or $type==NULL){
    showmsg('保存错误,请确保每项都不为空!' , 'index.php?act=host&my=add' , 5 , 1 , 1000);;
  } else {

      $sql="INSERT INTO `quan_nav` (`id`, `type`,  `domain`) VALUES (NULL, '$type',  '$domain');";

if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('添加成功".$DB->error()."',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=host'});</script>");
  }
  else{
  	exit("<script type='text/javascript'>layer.alert('添加失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=host'});</script>");
  }

  }
}elseif($my=='del'){
$id=intval($_GET['id']);
$sql=$DB->query("DELETE FROM quan_nav WHERE id='$id'");
if($sql){
    exit("<script type='text/javascript'>layer.alert('删除成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=host'});</script>");
    
}
else{
    exit("<script type='text/javascript'>layer.alert('删除失败',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=host'});</script>");
    
}
    
}

elseif($my=='del2'){
$checkbox=$_POST['checkbox'];
$i=0;
foreach($checkbox as $id){
  $DB->query("DELETE FROM quan_nav WHERE id='$id'");
  $i++;
}
exit("<script type='text/javascript'>layer.alert('成功删除{$i}个域名',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=host'});</script>");
}
else{
$numrows=$DB->count("SELECT count(*) from quan_nav WHERE 1");
$sql=" 1";
$con='共有 <b>'.$numrows.'</b> 个网址';
$con.='&nbsp&nbsp<a href="index.php?act=host&my=add" class="btn btn-primary btn-sm">添加</a>';
echo $con;
?>
      <div class="table-responsive">
    <form name="form1" method="post" action="index.php?act=host&my=del2">
        <table class="table table-striped">
          <thead><tr><th>名称</th><th>网址</th></th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=10;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;






}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM quan_nav WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
echo '<tr><td><input type="checkbox" name="checkbox[]" value="'.$res['id'].'"> '.htmlspecialchars($res['type']).'</td><td>'.$res['domain'].'</td><td><a href="index.php?act=host&my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此记录吗？\');">删除</a></td></tr>';
}
?>
</table>
</table>
<input class="btn btn-xs btn btn-secondary" type="submit" name="Submit" value="删除选中">
</form>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="index.php?act=host&page='.$first.$link.'">首页</a></li>';
echo '<li><a href="index.php?act=host&page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="index.php?act=host&page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="index.php?act=host&page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="index.php?act=host&page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="index.php?act=host&page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>


























<?php }elseif($_GET['act']=="set"){?>
    
    
    <main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">网站配置</a> </li>
              </ul>
<div class="tab-content">
<div class="tab-pane active">
    <?php
if(isset($_POST['setsubmit'])) {
   $sitename=daddslashes($_POST['sitename']);
    $kfqq=daddslashes($_POST['kfqq']);
    $keywords=daddslashes($_POST['keywords']);
    $description=daddslashes($_POST['description']);
        $announcement=daddslashes($_POST['announcement']);
        $bottom=daddslashes($_POST['bottom']);
            $beian=daddslashes($_POST['beian']);
    $sql="UPDATE `quan_config` SET `sitename` = '$sitename', `keywords` = '$keywords', `description` = '$description', `kfqq` = '$kfqq', `announcement` = '$announcement', `bottom` = '$bottom',  `beian` = '$beian' WHERE `quan_config`.`id` = 1";
    if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('修改成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=set'});</script>");
  }
  else
  	exit("<script type='text/javascript'>layer.alert('修改失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=set'});</script>");
  }
?>
<div class="panel-body">
  <form action="index.php?act=set" method="post" class="form-horizontal" role="form">
    		<div class="form-group">
	  <label class="col-xs-12">网站标题</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入网站标题" name="sitename" value="<?php echo $conf['sitename']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12 ">关键词</label>
	  <div class="col-xs-12"><input type="text" placeholder="输入关键词" name="keywords" value="<?php echo $conf['keywords']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
                    <label class="col-xs-12" for="example-textarea-input">网站描述</label>
                    <div class="col-xs-12">
                      <textarea class="form-control" id="example-textarea-input" name="description" rows="5" placeholder="输入网站描述"><?php echo $conf['description'];?></textarea>
                    </div>
                  </div></br>
			<div class="form-group">
	  <label class="col-xs-12 ">站长QQ</label>
	  <div class="col-xs-12"><input type="text" name="kfqq" value="<?php echo $conf['kfqq']; ?>" class="form-control border-input"/></div>
	</div><br/>

    <div class="form-group">
                    <label class="col-xs-12" for="example-textarea-input">网站通知</label>
                    <div class="col-xs-12">
                      <textarea class="form-control" id="example-textarea-input" name="announcement" rows="5" placeholder="输入网站通知"><?php echo $conf['announcement'];?></textarea>
                    </div>
                  </div></br>

     <div class="form-group">
                    <label class="col-xs-12" for="example-textarea-input">底部自定义</label>
                    <div class="col-xs-12">
                      <textarea class="form-control" id="example-textarea-input" name="bottom" rows="5" placeholder="输入底部内容"><?php echo $conf['bottom'];?></textarea>
                    </div>
                  </div></br>
                  <div class="form-group">
	  <label class="col-xs-12 ">备案信息</label>
	  <div class="col-xs-12"><input type="text"placeholder="输入备案号" name="beian" value="<?php echo $conf['beian']; ?>" class="form-control border-input"/></div>
	</div><br/>
                  
                  

	<div class="form-group">
            <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="setsubmit" value="修改" class="btn btn-info btn-fill btn-block" style="border-radius:10px;"/>
	 </div>
	</div>
  </form>
</div>
</div>

      </div>
      </div>
    
    
    


<?php } elseif($_GET['act']=="ztsz"){?>



    <main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">主题配置</a> </li>
              </ul>
<div class="tab-content">
<div class="tab-pane active">
    <?php
if(isset($_POST['mbsubmit'])) {
    $template=daddslashes($_POST['template']);
    
    $sql="UPDATE `quan_config` SET  `template` = '$template'   WHERE `quan_config`.`id` = 1";
    if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('修改成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=ztsz'});</script>");
  }
  else
  	exit("<script type='text/javascript'>layer.alert('修改失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=ztsz'});</script>");
  }
?>
<div class="panel-body">
  <form action="index.php?act=ztsz" method="post" class="form-horizontal" role="form">

                <div class="form-group">
	  <label class="col-xs-12 ">主题配置</label>
	  <div class="col-xs-12"><select name="template" class="form-control border-input">
		<option value="01" <?php if($conf['template']==01){echo'selected';} ?>>晴空渐樱</option>
				<option value="02" <?php if($conf['template']==02){echo'selected';} ?>>浅悠之暖</option>
				<option value="03" <?php if($conf['template']==03){echo'selected';} ?>>敬请期待...</option>
	  </select></div>
	  </div><br/>



	
	<div class="form-group">
	  <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="mbsubmit" value="修改" class="btn btn-info btn-fill btn-block"style="border-radius:10px;"/>
	 </div>
	</div>
  </form>
</div>
</div>
<script>

</script>
      </div>
      </div>


<?php } elseif($_GET['act']=="pass"){?>

<main class="lyear-layout-content">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="card">
    <ul class="nav nav-tabs page-tabs">
                <li class="active"> <a href="#!">修改密码</a> </li>
              </ul>
<div class="card-header"></div>
<div class="card-body">
<?php
if(isset($_POST['pass_submit'])) {
    $user=daddslashes($_POST['user']);
    $pwd0=daddslashes($_POST['pwd0']);
    $pwd1=daddslashes($_POST['pwd1']);
    $pwd2=daddslashes($_POST['pwd2']);
	if($user==NULL){
exit("<script type='text/javascript'>layer.alert('用户名不能为空',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=pass'});</script>"); }
	if($pwd1==NULL){
	exit("<script type='text/javascript'>layer.alert('密码不能为空',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=pass'});</script>");
}
	if($pwd0!=$conf['pwd']){
exit("<script type='text/javascript'>layer.alert('旧密码错误',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=pass'});</script>"); }
	if($pwd1!=$pwd2){
	    exit("<script type='text/javascript'>layer.alert('两次密码不一样',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=pass'});</script>");  }
	    else{
	        $sql="UPDATE `quan_config` SET `user` = '$user', `pwd` = '$pwd1' WHERE `quan_config`.`id` = 1";
	        if($DB->query($sql)){
exit("<script type='text/javascript'>layer.alert('修改成功',{icon:6,closeBtn:0},function(){window.location.href='index.php?act=pass'});</script>");
  }
  else
  	exit("<script type='text/javascript'>layer.alert('修改失败".$DB->error()."',{icon:5,closeBtn:0},function(){window.location.href='index.php?act=pass'});</script>");
  }
	        
	        
	    }


?>
<div class="panel-body">
  <form action="index.php?act=pass" method="post" class="form-horizontal" role="form">
    		<div class="form-group">
	  <label class="col-xs-12">管理账号</label>
	  <div class="col-xs-12"><input type="text" name="user" value="<?php echo $conf['user']; ?>" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12">旧密码</label>
	  <div class="col-xs-12"><input type="text" name="pwd0" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12">新密码</label>
	  <div class="col-xs-12"><input type="text" name="pwd1" class="form-control border-input"/></div>
	</div><br/>
    		<div class="form-group">
	  <label class="col-xs-12">重复密码</label>
	  <div class="col-xs-12"><input type="text" name="pwd2" class="form-control border-input"/></div>
	</div><br/>
	<div class="form-group">
	  <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="pass_submit" value="修改" class="btn btn-info btn-fill btn-block "style="border-radius:10px;"/>
	 </div>
	</div>
  </form>
</div>
</div>
</div>
</div>


<?php } else{?>
   <main class="lyear-layout-content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-6 col-lg-3">
            <div class="card">
              <div class="card-header" style="background:#c0cbe2;border-top-left-radius:10px;border-top-right-radius:10px;">
                <h4>更新日志</h4>
              </div>
              <div class="card-body">
               <li class="list-group-item">
                    1.后台添加多种模式。
               </li>
               <li class="list-group-item">
                    2.程序已添加安装程序。
               </li>
               <li class="list-group-item">
                    3.页面添加网易云年度报告。
               </li>
               <li class="list-group-item">
                    4.优化顶部个性签名、iphone位置错乱。
               </li>
               <li class="list-group-item">
                    5.取消数据库适配emoji,采用通用编码形式
               </li>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-3">
           <div class="card">
              <div class="card-header"  style="background:#ff8685;border-top-left-radius:10px;border-top-right-radius:10px;">
                <h4>开发进度</h4>
              </div>
              <div class="card-body">
               <li class="list-group-item">
                            <b>前台：</b>
                            <div class="progress progress-striped progress-sm">
                            <div class="progress-bar progress-bar-success" style="width: 95%;"></div>
                          </div>
               </li>
               <li class="list-group-item">
                            <b>后台：</b>
                            <div class="progress progress-striped progress-sm">
                            <div class="progress-bar progress-bar-warning " style="width: 90%;"></div>
                          </div>
               </li>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-3">
            <div class="card">
              <div class="card-header" style="background:#5fcdca;border-top-left-radius:10px;border-top-right-radius:10px;">
                <h4>版本信息</h4>
              </div>
              <div class="card-body">
               <li class="list-group-item">
                            <b>版本号：</b><?php echo $conf['edition']; ?>
               </li>
               <li class="list-group-item">
                            <b>作者：</b><?php echo $conf['author']; ?>
               </li>
               <li class="list-group-item">
                            <b>QQ：</b><?php echo $conf['kfqq']; ?>
               </li>
              </div>
            </div>
          </div>
          
          <div class="col-sm-6 col-lg-3">
             <div class="card">
              <div class="card-header" style="background:#74a7ff;border-top-left-radius:10px;border-top-right-radius:10px;">
                <h4>服务器信息</h4>
              </div>
              <div class="card-body">
              <ul class="list-group">
                        <li class="list-group-item">
                            <b>PHP 版本：</b><?php echo phpversion() ?>
                            <?php if(ini_get('safe_mode')) { echo '线程安全'; } else { echo '非线程安全'; } ?>
                        </li>
                        <li class="list-group-item">
                            <b>操作系统：</b><?PHP echo PHP_OS; ?>
                        </li>
                        <li class="list-group-item">
                            <b>WEB软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
                        </li>
                        
                        <li class="list-group-item">
                            <b>服务器时间：</b><?php echo date("Y-m-d G:i:s");?>
                        </li>
                    </ul>
                    </div>
            </div>
           </div>

          <div class="col-sm-6 col-lg-12">
            <div class="card">
              <div class="card-header" style=" background:#c7f9cc;border-top-left-radius:10px;border-top-right-radius:10px;">
                <h4>版本介绍</h4>
              </div>
              <div class="card-body">
               <li><p style="color:#6c6db1">怀着曾经对WEB的热爱与追求，断断续续历时1坤年，为自己开发了个人主页---尘屿小站</p></li>
               <li><p style="color:#6566c2">对前端的执着，对细节的探索，尘屿小站由单页到不完整的后台版再到新版本，步步完善</p></li>
               <li><p style="color:#5e60d2">这个世界从不缺乏大佬，此站点可以二开，网站写的很一般，请勿抨击。只要能写出自己喜欢的东西，每个人都是最优秀的程序猿</p></li>
               <li><p style="color:#ff0000">此程序为开源代码，凡以金钱交易换取，非作者所为</p></li>
              </div>
            </div>
          </div>
          
      </div>
    </main>



<?php }
?>



