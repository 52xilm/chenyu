<?php
@header('Content-Type: text/html; charset=UTF-8');
include '../includes/common.php';
if(isset($_POST['user']) && isset($_POST['pass'])){
	$user=daddslashes($_POST['user']);
	$pass=daddslashes($_POST['pass']);
	if($user==$conf['user'] && $pass==$conf['pwd']) {
		$session=md5($user.$pass.$password_hash);
		$token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
		setcookie("admin_token", $token, time() + 604800, ";\r\n");
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('登陆成功！');window.location.href='./';</script>");
	}else {
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('账号或密码不对哟！');history.go(-1);</script>");
	}
}elseif(isset($_GET['logout'])){
	setcookie("admin_token", "", time() - 604800, ";\r\n");
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功退出本次登陆！');window.location.href='./login.php';</script>");
}elseif($islogin==1){
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('登陆成功欢迎回来！');window.location.href='./';</script>");
}
?>
<!DOCTYPE html>
<!--作者：尘屿 -->
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" />
<title>登录页面</title>
<link rel="icon" href="/favicon.ico" type="image/ico">
<meta name="author" content="chenyu">
<link href="/assets/LightYear/css/bootstrap.min.css" rel="stylesheet">
<link href="/assets/css/materialdesignicons.min.css" rel="stylesheet">
<link href="/assets/LightYear/css/style.min.css" rel="stylesheet">
<style>
.lyear-wrapper {
    position: relative;
}
.lyear-login {
    background:radial-gradient(at 37.03080980186364% 92.74770360594952%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 1) 0%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 0) 100%), radial-gradient(at 91.08156808002138% 8.079489758295267%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 1) 0%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 0) 100%), radial-gradient(at 49.44682660041033% 50.01772572519081%, hsla(346.95652173913044, 74.19354838709674%, 81.76470588235294%, 1) 0%, hsla(346.95652173913044, 74.19354838709674%, 81.76470588235294%, 0) 100%), radial-gradient(at 87.18744182053693% 71.5536698991614%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 1) 0%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 0) 100%), radial-gradient(at 38.17493160170311% 25.77475686228894%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 1) 0%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 0) 100%), radial-gradient(at 34.260516012772335% 97.05475192625259%, hsla(346.95652173913044, 74.19354838709674%, 81.76470588235294%, 1) 0%, hsla(346.95652173913044, 74.19354838709674%, 81.76470588235294%, 0) 100%), radial-gradient(at 90.69993607343365% 66.87450410773424%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 1) 0%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 0) 100%), radial-gradient(at 51.49558903320708% 38.046424483703014%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 1) 0%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 0) 100%), radial-gradient(at 98.5176042082% 53.00335089293438%, hsla(346.95652173913044, 74.19354838709674%, 81.76470588235294%, 1) 0%, hsla(346.95652173913044, 74.19354838709674%, 81.76470588235294%, 0) 100%), radial-gradient(at 26.38806329339043% 10.402514341499014%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 1) 0%, hsla(204.82758620689657, 67.44186046511625%, 74.70588235294117%, 0) 100%), radial-gradient(at 5.266690833022403% 53.20222067191778%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 1) 0%, hsla(266.0869565217391, 47.91666666666666%, 81.17647058823529%, 0) 100%);
    display: flex !important;
    min-height: 100vh;
    align-items: center !important;
    justify-content: center !important;
}
.lyear-login:after{
    content: '';
    min-height: inherit;
    font-size: 0;
}
.login-center {
    background-color: rgba(0,0,0,0.4);
    min-width: 29.25rem;
    padding: 2.14286em 3.57143em;
    border-radius: 10px;
    margin: 2.85714em;
}
.login-header {
    margin-bottom: 1.5rem !important;
}
.login-center .has-feedback.feedback-left .form-control {
    padding-left: 38px;
    padding-right: 12px;
    background-color: rgba(0,0,0,0);
    border-color: #d2d2d2;
}
.login-center .has-feedback.feedback-left .form-control-feedback {
    left: 0;
    right: auto;
    width: 38px;
    height: 38px;
    line-height: 38px;
    z-index: 4;
    color: #dcdcdc;
}
.login-center .has-feedback.feedback-left.row .form-control-feedback {
    left: 15px;
}
.login-center .form-control::-webkit-input-placeholder{ 
    color: rgba(255, 255, 255, .8);
} 
.login-center .form-control:-moz-placeholder{ 
    color: rgba(255, 255, 255, .8);
} 
.login-center .form-control::-moz-placeholder{ 
    color: rgba(255, 255, 255, .8);
} 
.login-center .form-control:-ms-input-placeholder{ 
    color: rgba(255, 255, 255, .8);
}
.login-center .custom-control-label::before {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(0, 0, 0, 0.1);
}
.login-center .lyear-checkbox span::before {
    border-color: rgba(255,255,255,.075)
}
</style>
</head>
<body>
<div class="row lyear-wrapper" style="background-color:#f2f1f6; background-size: cover;">
  <div class="lyear-login">
    <div class="login-center">
      <div class="login-header text-center">
        <a href=""> <img style="border-radius:100%; width:100px; height:100px;" src="/assets/img/logo-sidebar.png"> </a>
      </div>
      <form action="./login.php" method="post" class="form-horizontal" role="form">
        
        <div class="input-group has-feedback feedback-left">
              <input type="text" name="user" value="<?php echo @$_POST['user'];?>" class="form-control" placeholder="用户名" required="required"/>
              <span class="mdi mdi-account form-control-feedback" aria-hidden="true"></span>
            </div>
            <br>
        <div class="input-group has-feedback feedback-left">
              <input type="password" name="pass" class="form-control" placeholder="密码" required="required"/>
               <span class="mdi mdi-lock form-control-feedback" aria-hidden="true"></span>
            </div>
        <div class="form-group has-feedback feedback-left row">
        </div>
        <div class="form-group">
            <form>
          <button class="btn btn-block btn-primary" type="submit" >立即登录</button></form>
        </div>
      </form>
      <footer class="col-sm-12 text-center text-white">
      </footer>
    </div>
  </div>
</div>
<script type="text/javascript" src="/assets/LightYear/js/jquery.min.js"></script>
<script type="text/javascript" src="/assets/LightYear/js/bootstrap.min.js"></script>
<script type="text/javascript">;</script>
</body>
</html>